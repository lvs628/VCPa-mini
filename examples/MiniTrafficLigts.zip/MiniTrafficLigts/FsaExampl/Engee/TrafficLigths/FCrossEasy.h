#ifndef FCROSSEASY_H
#define FCROSSEASY_H
#include "FCrosswalk.h"

class FCrossEasy: public FCrosswalk
{
public:
    void timerEvent(QTimerEvent* t);

    void virtual FResetActions();
    bool FCreationOfLinksForVariables();
    FCrossEasy(string strNam = "FCrossEasy");
    CVar    *pVarMaxCntr;
    void run();
    QElapsedTimer TimerEvent;

protected:
    void y14();

};

#endif // FCROSSEASY_H
