#ifndef FCOMMONCOUNTER_H
#define FCOMMONCOUNTER_H


#include "lfsaappl.h"
#include <QElapsedTimer>  // Добавляем для измерения времени

class FCommonCounter :
    public LFsaAppl
{
public:
    bool FCreationOfLinksForVariables();
    FCommonCounter(string strNam);
    virtual ~FCommonCounter(void);
    CVar    *pVarCntr;
    CVar    *pVarMaxCntr;
    QElapsedTimer Timer;
    qint64 TimeMs{0};
    QString formatTime(qint64 milliseconds);  // Метод для форматирования времени
protected:
    int x1(); int x2(); int x3(); int x12();
    void y1(); void y2(); void y3(); void y4(); void y12();
};

#endif // FCOMMONCOUNTER_H
