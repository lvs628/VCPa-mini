/*
#include "Config.h"
#include <Arduino.h>
#include <QString>
#include <QElapsedTimer>  // Добавляем для измерения времени

long lTheNumberOfTheCurrentFrame = 0;
unsigned long ulStartTime;
unsigned long ulEndTime;
long lNumberOfFrames=1000;

// Определение пинов для светофоров
// Состояния потоков для автоматического режима
enum FlowState {
    STATE_RED,
    STATE_RED_YELLOW,
    STATE_GREEN,
    STATE_BLINKING,
    STATE_YELLOW
};

#include "lfsaappl.h"
// Класс для независимого управления светофором с синхронизацией для веб-интерфейса
extern LArc TBL_Traffic[];
class TrafficLight: public LFsaAppl
{
private:
    bool isPedestrian;
    
    bool redState;
    bool yellowState;
    bool greenState;
    
    // Указатели на переменные для веб-интерфейса
    bool* webRedState;
    bool* webYellowState;
    bool* webGreenState;
    bool* webBlinkingState;
    
public:
    unsigned long TimeMs;
    TrafficLight(bool pedestrian, string strNam, LArc *pTBL=TBL_Traffic) 
        : LFsaAppl(pTBL, strNam, nullptr), 
        isPedestrian(pedestrian) 
    {
        
        redState = false;
        yellowState = false;
        greenState = false;
        
        // Инициализация указателей
        webRedState = nullptr;
        webYellowState = nullptr;
        webGreenState = nullptr;
        webBlinkingState = nullptr;
        
        Timer.start();
        TimeMs = Timer.elapsed();
        
    }

    QElapsedTimer Timer;
    
    // Регистрация переменных для веб-интерфейса
    void registerWebStates(bool* red, bool* yellow, bool* green, bool* blinking) {
        webRedState = red;
        webYellowState = yellow;
        webGreenState = green;
        webBlinkingState = blinking;
        updateWebStates();
    }
    
    // Обновление веб-переменных в соответствии с текущим состоянием
    void updateWebStates() {
        if (webRedState) *webRedState = redState;
        if (webYellowState) *webYellowState = yellowState;
        if (webGreenState) *webGreenState = greenState;
        if (webBlinkingState) *webBlinkingState = false; // Blinking обрабатывается отдельно
    }
   
    // Установка/сброс отдельных цветов
    void setRed(bool on) {
        redState = on;
    }
    
    void setYellow(bool on) {
        if (isPedestrian) return;
        yellowState = on;
    }
    
    void setGreen(bool on) {
        greenState = on;
    }
    
    // Установка предопределенных комбинаций
    void setRedOnly() {
        redState = true;
        yellowState = false;
        greenState = false;
    }
    
    void setYellowOnly() {
        if (isPedestrian) return;
        redState = false;
        yellowState = true;
        greenState = false;
    }
    
    void setGreenOnly() {
        redState = false;
        yellowState = false;
        greenState = true;
    }
    
    void setRedYellow() {
        if (isPedestrian) return;
        redState = true;
        yellowState = true;
        greenState = false;
    }
    
    void setAllOff() {
        redState = false;
        yellowState = false;
        greenState = false;
    }
    
    void setAllOn() {
        redState = true;
        yellowState = true;
        greenState = true;
    }
    
    // Получение текущих состояний
    bool isRedOn() { return redState; }
    bool isYellowOn() { return yellowState; }
    bool isGreenOn() { return greenState; }
    
    // Специальные методы для пешеходного
    void setPedestrianRed() {
        redState = true;
        greenState = false;
    }
    
    void setPedestrianGreen() {
        redState = false;
        greenState = true;
    }
    
    void setPedestrianBlinking(bool state) {
        greenState = state;
        redState = false;
        if (webBlinkingState) *webBlinkingState = true;
        if (webBlinkingState && !state) *webBlinkingState = false;
    }
};

// Глобальные объекты светофоров
TrafficLight car1(false, "car1");
TrafficLight car2(false, "car2");
TrafficLight pedestrian(true, "ped");

// Переменные для веб-интерфейса
struct WebLightsState {
    bool car1_red = false;
    bool car1_yellow = false;
    bool car1_green = false;
    bool car1_blinking = false;
    
    bool car2_red = false;
    bool car2_yellow = false;
    bool car2_green = false;
    bool car2_blinking = false;
    
    bool ped_red = false;
    bool ped_green = false;
    bool ped_blinking = false;
} webState;

// Текущие состояния для автоматического режима
FlowState car1AutoState = STATE_RED;
FlowState car2AutoState = STATE_RED;
FlowState pedAutoState = STATE_RED;

unsigned long stateStartTime = 0;
unsigned long lastBlinkTime = 0;
bool blinkState = false;
bool autoMode = true;

// Данные для веб-интерфейса
struct {
    long car1Remaining = 0;
    long car2Remaining = 0;
    long pedRemaining = 0;
} timers;

// ==================== ФУНКЦИИ УПРАВЛЕНИЯ ИЗ C++ (С СИНХРОНИЗАЦИЕЙ) ====================

// Функции для управления светофорами из кода C++ с обновлением веб-интерфейса
void manualSetCar1Color(const QString& color, bool state) {
    autoMode = false;
    
    if (color == "red") {
        car1.setRed(state);
        webState.car1_red = state;
//        Serial.print("C++ MANUAL: CAR1 RED -> ");
//        Serial.println(state ? "ON" : "OFF");
    } else if (color == "yellow") {
        car1.setYellow(state);
        webState.car1_yellow = state;
//        Serial.print("C++ MANUAL: CAR1 YELLOW -> ");
//        Serial.println(state ? "ON" : "OFF");
    } else if (color == "green") {
        car1.setGreen(state);
        webState.car1_green = state;
//        Serial.print("C++ MANUAL: CAR1 GREEN -> ");
//        Serial.println(state ? "ON" : "OFF");
    }
    
    // Сброс blinking при ручном управлении
    webState.car1_blinking = false;
}

void manualSetCar2Color(const QString& color, bool state) {
    autoMode = false;
    
    if (color == "red") {
        car2.setRed(state);
        webState.car2_red = state;
//        Serial.print("C++ MANUAL: CAR2 RED -> ");
//        Serial.println(state ? "ON" : "OFF");
    } else if (color == "yellow") {
        car2.setYellow(state);
        webState.car2_yellow = state;
//        Serial.print("C++ MANUAL: CAR2 YELLOW -> ");
//        Serial.println(state ? "ON" : "OFF");
    } else if (color == "green") {
        car2.setGreen(state);
        webState.car2_green = state;
//        Serial.print("C++ MANUAL: CAR2 GREEN -> ");
//        Serial.println(state ? "ON" : "OFF");
    }
    
    webState.car2_blinking = false;
}

void manualSetPedColor(const QString& color, bool state) {
    autoMode = false;
    
    if (color == "red") {
        pedestrian.setRed(state);
        webState.ped_red = state;
//        Serial.print("C++ MANUAL: PED RED -> ");
//        Serial.println(state ? "ON" : "OFF");
    } else if (color == "green") {
        pedestrian.setGreen(state);
        webState.ped_green = state;
//        Serial.print("C++ MANUAL: PED GREEN -> ");
//        Serial.println(state ? "ON" : "OFF");
    }
    
    webState.ped_blinking = false;
}

// Функция для установки предустановленных комбинаций из C++
void manualSetPreset(const QString& light, const QString& preset) {
    autoMode = false;
    
    if (light == "car1") {
        if (preset == "off") {
            car1.setAllOff();
            webState.car1_red = webState.car1_yellow = webState.car1_green = false;
//            Serial.println("C++ MANUAL: CAR1 ALL OFF");
        } else if (preset == "all_on") {
            car1.setAllOn();
            webState.car1_red = webState.car1_yellow = webState.car1_green = true;
//            Serial.println("C++ MANUAL: CAR1 ALL ON");
        } else if (preset == "red_only") {
            car1.setRedOnly();
            webState.car1_red = true;
            webState.car1_yellow = webState.car1_green = false;
//            Serial.println("C++ MANUAL: CAR1 ONLY RED");
        } else if (preset == "yellow_only") {
            car1.setYellowOnly();
            webState.car1_yellow = true;
            webState.car1_red = webState.car1_green = false;
//            Serial.println("C++ MANUAL: CAR1 ONLY YELLOW");
        } else if (preset == "green_only") {
            car1.setGreenOnly();
            webState.car1_green = true;
            webState.car1_red = webState.car1_yellow = false;
//            Serial.println("C++ MANUAL: CAR1 ONLY GREEN");
        } else if (preset == "red_yellow") {
            car1.setRedYellow();
            webState.car1_red = webState.car1_yellow = true;
            webState.car1_green = false;
//            Serial.println("C++ MANUAL: CAR1 RED+YELLOW");
        }
        webState.car1_blinking = false;
    } 
    else if (light == "car2") {
        if (preset == "off") {
            car2.setAllOff();
            webState.car2_red = webState.car2_yellow = webState.car2_green = false;
//            Serial.println("C++ MANUAL: CAR2 ALL OFF");
        } else if (preset == "all_on") {
            car2.setAllOn();
            webState.car2_red = webState.car2_yellow = webState.car2_green = true;
//            Serial.println("C++ MANUAL: CAR2 ALL ON");
        } else if (preset == "red_only") {
            car2.setRedOnly();
            webState.car2_red = true;
            webState.car2_yellow = webState.car2_green = false;
//            Serial.println("C++ MANUAL: CAR2 ONLY RED");
        } else if (preset == "yellow_only") {
            car2.setYellowOnly();
            webState.car2_yellow = true;
            webState.car2_red = webState.car2_green = false;
//            Serial.println("C++ MANUAL: CAR2 ONLY YELLOW");
        } else if (preset == "green_only") {
            car2.setGreenOnly();
            webState.car2_green = true;
            webState.car2_red = webState.car2_yellow = false;
//            Serial.println("C++ MANUAL: CAR2 ONLY GREEN");
        } else if (preset == "red_yellow") {
            car2.setRedYellow();
            webState.car2_red = webState.car2_yellow = true;
            webState.car2_green = false;
//            Serial.println("C++ MANUAL: CAR2 RED+YELLOW");
        }
        webState.car2_blinking = false;
    }
    else if (light == "ped") {
        if (preset == "off") {
            pedestrian.setAllOff();
            webState.ped_red = webState.ped_green = false;
//            Serial.println("C++ MANUAL: PED ALL OFF");
        } else if (preset == "red_only") {
            pedestrian.setPedestrianRed();
            webState.ped_red = true;
            webState.ped_green = false;
//            Serial.println("C++ MANUAL: PED ONLY RED");
        } else if (preset == "green_only") {
            pedestrian.setPedestrianGreen();
            webState.ped_green = true;
            webState.ped_red = false;
//            Serial.println("C++ MANUAL: PED ONLY GREEN");
        }
        webState.ped_blinking = false;
    }
}

// Функция для переключения цвета (toggle) из C++
void manualToggleColor(const QString& light, const QString& color) {
    autoMode = false;
    
    if (light == "car1") {
        if (color == "red") {
            bool newState = !car1.isRedOn();
            car1.setRed(newState);
            webState.car1_red = newState;
//            Serial.print("C++ TOGGLE: CAR1 RED -> ");
//            Serial.println(newState ? "ON" : "OFF");
        } else if (color == "yellow") {
            bool newState = !car1.isYellowOn();
            car1.setYellow(newState);
            webState.car1_yellow = newState;
//            Serial.print("C++ TOGGLE: CAR1 YELLOW -> ");
//            Serial.println(newState ? "ON" : "OFF");
        } else if (color == "green") {
            bool newState = !car1.isGreenOn();
            car1.setGreen(newState);
            webState.car1_green = newState;
//            Serial.print("C++ TOGGLE: CAR1 GREEN -> ");
//            Serial.println(newState ? "ON" : "OFF");
        }
        webState.car1_blinking = false;
    } 
    else if (light == "car2") {
        if (color == "red") {
            bool newState = !car2.isRedOn();
            car2.setRed(newState);
            webState.car2_red = newState;
//            Serial.print("C++ TOGGLE: CAR2 RED -> ");
//            Serial.println(newState ? "ON" : "OFF");
        } else if (color == "yellow") {
            bool newState = !car2.isYellowOn();
            car2.setYellow(newState);
            webState.car2_yellow = newState;
//            Serial.print("C++ TOGGLE: CAR2 YELLOW -> ");
//            Serial.println(newState ? "ON" : "OFF");
        } else if (color == "green") {
            bool newState = !car2.isGreenOn();
            car2.setGreen(newState);
            webState.car2_green = newState;
//            Serial.print("C++ TOGGLE: CAR2 GREEN -> ");
//            Serial.println(newState ? "ON" : "OFF");
        }
        webState.car2_blinking = false;
    } 
    else if (light == "ped") {
        if (color == "red") {
            bool newState = !pedestrian.isRedOn();
            pedestrian.setRed(newState);
            webState.ped_red = newState;
//            Serial.print("C++ TOGGLE: PED RED -> ");
//            Serial.println(newState ? "ON" : "OFF");
        } else if (color == "green") {
            bool newState = !pedestrian.isGreenOn();
            pedestrian.setGreen(newState);
            webState.ped_green = newState;
//            Serial.print("C++ TOGGLE: PED GREEN -> ");
//            Serial.println(newState ? "ON" : "OFF");
        }
        webState.ped_blinking = false;
    }
}

// Возврат в автоматический режим из C++
void setCar1AutoState(FlowState state);
void setCar2AutoState(FlowState state);
void setPedAutoState(FlowState state);

// ==================== АВТОМАТИЧЕСКИЙ РЕЖИМ ====================

unsigned long lastManualSequenceTime = 0;
int manualSequenceStep = 0;
bool demo = true;
unsigned long StartSequenceTime;
unsigned long StopSequenceTime;
unsigned long nowStep=0;

// ==================== SETUP ====================
void setup() {
    Serial.begin(115200);
    delay(1000);
    Serial.println("\n\n========================================");
    Serial.println("=== TRAFFIC LIGHT CONTROLLER v3.0 ===");
    Serial.println("========================================\n");
    
    // Начальное состояние: все красный
    car1.setRedOnly();
    car2.setRedOnly();
    pedestrian.setPedestrianRed();
    
    // Инициализация webState
    webState.car1_red = true;
    webState.car1_yellow = false;
    webState.car1_green = false;
    webState.car1_blinking = false;
    
    webState.car2_red = true;
    webState.car2_yellow = false;
    webState.car2_green = false;
    webState.car2_blinking = false;
    
    webState.ped_red = true;
    webState.ped_green = false;
    webState.ped_blinking = false;
    
    car1AutoState = STATE_RED;
    car2AutoState = STATE_RED;
    pedAutoState = STATE_RED;
    
    timers.car1Remaining = 0;
    timers.car2Remaining = 0;
    timers.pedRemaining = 0;
    
    delay(2000);
    
    // Запускаем автоматический режим с красно-желтого для CAR1
    car1AutoState = STATE_RED_YELLOW;
    setCar1AutoState(car1AutoState);
    stateStartTime = millis();
    
    Serial.println("✓ System started! Auto mode with CAR1 RED+YELLOW");
    
#if defined (IF_CONNECT_WIFI)
    connectToWiFi();
#endif    
    
    if (WiFi.status() == WL_CONNECTED) {
        server.on("/", handleRoot);
        server.on("/api/status", handleStatus);
        server.on("/api/toggle", handleToggle);
        server.on("/api/preset", handlePreset);
        server.on("/api/auto_mode", handleAutoMode);
        server.begin();
        Serial.println("✓ HTTP server started");
        Serial.println("========================================");
        Serial.print("🌐 Open in browser: http://");
        Serial.println(WiFi.localIP());
        Serial.println("========================================\n");
    }
    
    // Пример: раскомментируйте для запуска демо-последовательности
    delay(5000);
    demo = true;
    autoMode = false;
    Serial.println("=== Starting demo sequence from C++ ===");
    lNumberOfFrames=10;         // один цикл
    pedestrian.TimeMs = 0;

    ulStartTime = millis();
    stateStartTime = millis();
    StartSequenceTime = millis();
}

// ==================== LOOP ====================
void loop() {
    // Запуск демо-последовательности (раскомментируйте для тестирования)
void runDemoSequence();    
    runDemoSequence();
    
    if (WiFi.status() == WL_CONNECTED) {
        server.handleClient();
    }
    
    delay(10);
}
// Демо-последовательность в соответствии с временной диаграммой
// Шаг = 1 секунда
bool bPrintCadr=false;
int nSavStep=0;
void Lights(int SequenceStep);
void runDemoSequence() {
    if (!demo) return;
    if (lTheNumberOfTheCurrentFrame>15) return;
    if (lNumberOfFrames == lTheNumberOfTheCurrentFrame && demo) {
        if (nSavStep!= manualSequenceStep) {
            nSavStep = manualSequenceStep;
            ulEndTime = millis();
            Serial.printf("Frame=%d\n", lTheNumberOfTheCurrentFrame);
            Serial.printf("test running time = %d\n", ulEndTime - ulStartTime);
            demo = false;
            return;
        }
    }
    unsigned long now = millis();
    
    if (now - lastManualSequenceTime >= 100) {
        lastManualSequenceTime = now;
        Lights(manualSequenceStep);
        switch(manualSequenceStep) {
            // t = 0 сек: Начальное состояние
            case 0:
                if (StartSequenceTime==0 && lNumberOfFrames == 0) {
                    StartSequenceTime = millis();
                    nSavStep = -1;
                }
                else {
                    if (manualSequenceStep == 0 && !bPrintCadr) {
                        bPrintCadr = true;
                        lTheNumberOfTheCurrentFrame++;
//                        Serial.printf("Frame=%d\n", lTheNumberOfTheCurrentFrame);
                    }
                }
                break;
            case 10:
                    bPrintCadr = false;
                break;
            default:
                break;
        }
    }
    manualSequenceStep++;
//    Serial.printf("Step=%d\n", manualSequenceStep);
}

bool bViewPed = false;
void Lights(int SequenceStep) {

    if (SequenceStep==0) {
        if (!bViewPed) {
            unsigned long ttt = millis();
            pedestrian.TimeMs = ttt - pedestrian.TimeMs;
            Serial.printf("Time(%s)=%d\n", "pedestrian", pedestrian.TimeMs);
            pedestrian.TimeMs = millis();
            bViewPed = true;
        }
        else {
            pedestrian.TimeMs = millis();
        }
    }

    switch(SequenceStep) {
        // t = 0 сек: Начальное состояние
        case 0:
            StartSequenceTime = millis();
//                Serial.println("\n=== t=0: CAR1 RED, CAR2 GREEN, PED RED ===");
            // CAR1: только красный
            manualSetCar1Color("red", true);
            manualSetCar1Color("yellow", false);
            manualSetCar1Color("green", false);
            // CAR2: только зеленый
            manualSetCar2Color("red", false);
            manualSetCar2Color("yellow", false);
            manualSetCar2Color("green", true);
            // PED: только красный
            manualSetPedColor("red", true);
            manualSetPedColor("green", false);
            break;
        
        // t = 10 сек: Начало мигания CAR2
        case 10:
//                Serial.println("=== t=10: CAR2 GREEN OFF (мигание 1/6) ===");
            manualSetCar2Color("green", false);
            bViewPed = false;
            break;
        case 11:
//                Serial.println("=== t=11: CAR2 GREEN ON (мигание 2/6) ===");
            manualSetCar2Color("green", true);
            break;
        case 12:
//                Serial.println("=== t=12: CAR2 GREEN OFF (мигание 3/6) ===");
            manualSetCar2Color("green", false);
            break;
        case 13:
//                Serial.println("=== t=13: CAR2 GREEN ON (мигание 4/6) ===");
            manualSetCar2Color("green", true);
            break;
        case 14:
//                Serial.println("=== t=14: CAR2 GREEN OFF (мигание 5/6) ===");
            manualSetCar2Color("green", false);
            break;
        
        // t = 15 сек: Желтый сигнал CAR2
        case 15:
//                Serial.println("=== t=15: CAR2 YELLOW ON ===");
            manualSetCar2Color("yellow", true);
            break;
        
        // t = 20 сек: Переключение на пешеходный
        case 20:
//                Serial.println("=== t=20: CAR2 RED ON, PED GREEN ON ===");
            manualSetCar2Color("red", true);
            manualSetCar2Color("yellow", false);
            manualSetCar2Color("green", false);
            manualSetPedColor("red", false);
            manualSetPedColor("green", true);
            break;
        
        // t = 30 сек: Подготовка CAR1 к движению
        case 30:
//                Serial.println("=== t=30: CAR1 YELLOW ON, CAR2 YELLOW OFF, PED RED ON ===");
            manualSetCar1Color("yellow", true);
            manualSetPedColor("red", true);
            manualSetPedColor("green", false);
            break;
        
        // t = 35 сек: Начало движения CAR1
        case 35:
//                Serial.println("=== t=35: CAR1 GREEN ON ===");
            manualSetCar1Color("red", false);
            manualSetCar1Color("yellow", false);
            manualSetCar1Color("green", true);
            break;
        
        // t = 45 сек: Начало мигания CAR1
        case 45:
//                Serial.println("=== t=45: CAR1 GREEN OFF (мигание 1/4) ===");
            manualSetCar1Color("green", false);
            break;
        case 46:
//                Serial.println("=== t=46: CAR1 GREEN ON (мигание 2/4) ===");
            manualSetCar1Color("green", true);
            break;
        case 47:
//                Serial.println("=== t=47: CAR1 GREEN OFF (мигание 3/4) ===");
            manualSetCar1Color("green", false);
            break;
        case 48:
//                Serial.println("=== t=48: CAR1 GREEN ON (мигание 4/4) ===");
            manualSetCar1Color("green", true);
            break;
        case 49:
//                Serial.println("=== t=49: CAR1 GREEN OFF ===");
            manualSetCar1Color("green", false);
            break;
        
        // t = 50 сек: Желтые сигналы
        case 50:
//              Serial.println("=== t=50: CAR1 YELLOW ON, CAR2 YELLOW ON ===");
            manualSetCar1Color("yellow", true);
            manualSetCar1Color("red", false);
            manualSetCar1Color("green", false);
            manualSetCar2Color("yellow", true);
            manualSetCar2Color("red", true);
            manualSetCar2Color("green", false);
            break;
        
        // t = 55 сек: Завершение и возврат в авторежим
        case 54:
                nowStep = millis();
                StopSequenceTime = nowStep - StartSequenceTime;
//                  Serial.printf("One SequenceTime = %d\n", StopSequenceTime);

//                Serial.println("=== t=55: DEMO COMPLETE ===");
//                Serial.println("=== Returning to AUTO mode ===");
//                returnToAutoMode();
//                demo = false;
//            lTheNumberOfTheCurrentFrame++;
            manualSequenceStep = -1;
            break;
        
        default:
            break;
    }
}
*/
/*
    switch(SequenceStep) {
        // t = 0 сек: Начальное состояние
        case 0:
            StartSequenceTime = millis();
            // CAR1: только красный
            // CAR2: только зеленый
            // PED: только красный
            break;
        // t = 10 сек: Начало мигания CAR2
        case 10:
//                Serial.println("=== t=10: CAR2 GREEN OFF (мигание 1/6) ===");
            break;
        case 11:
//                Serial.println("=== t=11: CAR2 GREEN ON (мигание 2/6) ===");
            break;
        case 12:
//                Serial.println("=== t=12: CAR2 GREEN OFF (мигание 3/6) ===");
            break;
        case 13:
//                Serial.println("=== t=13: CAR2 GREEN ON (мигание 4/6) ===");
            break;
        case 14:
//                Serial.println("=== t=14: CAR2 GREEN OFF (мигание 5/6) ===");
            break;
        // t = 15 сек: Желтый сигнал CAR2
        case 15:
//                Serial.println("=== t=15: CAR2 YELLOW ON ===");
            break;
        // t = 20 сек: Переключение на пешеходный
        case 20:
//                Serial.println("=== t=20: CAR2 RED ON, PED GREEN ON ===");
            manualSetCar2Color("red", true);
            manualSetCar2Color("yellow", false);
            manualSetCar2Color("green", false);
            manualSetPedColor("red", false);
            manualSetPedColor("green", true);
            break;
        // t = 30 сек: Подготовка CAR1 к движению
        case 30:
//                Serial.println("=== t=30: CAR1 YELLOW ON, CAR2 YELLOW OFF, PED RED ON ===");
            manualSetCar1Color("yellow", true);
            manualSetPedColor("red", true);
            manualSetPedColor("green", false);
            break;

        // t = 35 сек: Начало движения CAR1
        case 35:
//                Serial.println("=== t=35: CAR1 GREEN ON ===");
            manualSetCar1Color("red", false);
            manualSetCar1Color("yellow", false);
            manualSetCar1Color("green", true);
            break;

        // t = 45 сек: Начало мигания CAR1
        case 45:
//                Serial.println("=== t=45: CAR1 GREEN OFF (мигание 1/4) ===");
            manualSetCar1Color("green", false);
            break;
        case 46:
//                Serial.println("=== t=46: CAR1 GREEN ON (мигание 2/4) ===");
            manualSetCar1Color("green", true);
            break;
        case 47:
//                Serial.println("=== t=47: CAR1 GREEN OFF (мигание 3/4) ===");
            manualSetCar1Color("green", false);
            break;
        case 48:
//                Serial.println("=== t=48: CAR1 GREEN ON (мигание 4/4) ===");
            manualSetCar1Color("green", true);
            break;
        case 49:
//                Serial.println("=== t=49: CAR1 GREEN OFF ===");
            manualSetCar1Color("green", false);
            break;

        // t = 50 сек: Желтые сигналы
        case 50:
//              Serial.println("=== t=50: CAR1 YELLOW ON, CAR2 YELLOW ON ===");
            manualSetCar1Color("yellow", true);
            manualSetCar1Color("red", false);
            manualSetCar1Color("green", false);
            manualSetCar2Color("yellow", true);
            manualSetCar2Color("red", true);
            manualSetCar2Color("green", false);
            break;

        // t = 55 сек: Завершение и возврат в авторежим
        case 54:
                nowStep = millis();
                StopSequenceTime = nowStep - StartSequenceTime;
//                  Serial.printf("One SequenceTime = %d\n", StopSequenceTime);

//                Serial.println("=== t=55: DEMO COMPLETE ===");
//                Serial.println("=== Returning to AUTO mode ===");
//                returnToAutoMode();
//                demo = false;
//            lTheNumberOfTheCurrentFrame++;
            manualSequenceStep = -1;
            break;

        default:
            break;
    }
}
*/
