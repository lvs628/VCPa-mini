#include "stdafx.h"
#include "FTrafficLight.h"
#include "mainwindow.h"

extern MainWindow *pMainWindow;

LArc TBL_TrafficLight[] = {
    LArc("xx",		"xx","^x12",    "y12"), // есть указатель на переменную режима работы
    LArc("xx",		"ss","x12x5",   "y24"), // есть

    LArc("ss",		"st","x11","--"),       // на автоматное управление
    LArc("ss",		"tt","x13", "y13"),     // на таймерное управление, старт таймера
    LArc("ss",		"t2","x14","--"),        // на автоматное управление

    LArc("tt",		"t1","--",  "y11"),     // останов автомата
    LArc("t1",		"t1","--",  "--"),      //

    LArc("t2",		"t3","--",  "y17"),     // создание потока
    LArc("t3",		"t3","--",  "--"),      //

    LArc("st",		"R","x1",	"--"),
    LArc("st",		"Y","x2",	"--"),
    LArc("st",		"G","x3",	"--"),

    LArc("R",		"RY","x4",	"y2y3y5y7"),	//R=1, 30sec
    LArc("RY",		"G","x4",	"y4y8"),    	//G=1, Y=1, 5 sec
    LArc("G",		"G0","x4",	"y1y3y6y9"),	//G=1, 10 sec
    LArc("G0",		"G1","x4",	"y5y10"),		//G=0, 1 sec
    LArc("G1",		"G01","x4",	"y6y10"),		//G=1, 1 sec
    LArc("G01",		"G10","x4",	"y5y10"),		//G=0, 1 sec
    LArc("G10",		"G02","x4",	"y6y10"),		//G=1, 1 sec
    LArc("G02",		"Y","x4",	"y5y10"),		//G=0, 1 sec
    LArc("Y",		"R","x4",	"y1y4y5y8"),	//Y=1, 5 sec

    LArc()
};

FTrafficLight::FTrafficLight(string strNam, LArc *pTBL):
    QObject(),
    LFsaAppl(pTBL, strNam, nullptr)
{
    Timer.start();
}

FTrafficLight::~FTrafficLight(void)
{
    if (pThTrafficLights) delete pThTrafficLights;
    pThTrafficLights = nullptr;
    WaitForThreadToFinish(pThTrafficLights);
}

void FTrafficLight::FResetActions() {
    nCounter = 0;
    if (x1()) { nCounter = 0; }
    if (x2()) { nCounter = 50; }
    if (x3()) { nCounter = 35; }
    pVarCounter->SetDataSrc(nullptr, nCounter);
    pVarCounter->UpdateVariable();

    if (pThTrafficLights) delete pThTrafficLights;
    pThTrafficLights = nullptr;
}

void FTrafficLight::ExecuteThreadStep() {
    if (pThTrafficLights) pThTrafficLights->bIfExecuteStep = true;
}

void FTrafficLight::WaitForThreadToFinish(QThread *obj, unsigned long time) {
    if (obj) {
        // завершить поток
        pThTrafficLights->bIfRun = false;
        pThTrafficLights->quit();
        pThTrafficLights->wait(time);
        pThTrafficLights->terminate();
    }
    delete obj;
}

bool FTrafficLight::FCreationOfLinksForVariables() {
//    pVarControl =  CreateLocVar("nControl",	CLocVar::vtInteger, "control", true, "0");   // 0 - таймерное управление
//    pVarControl =  CreateLocVar("nControl",	CLocVar::vtInteger, "control", true, "1");   // 1 - автоматное управление
//    pVarControl =  CreateLocVar("nControl",	CLocVar::vtInteger, "control", true, "2");   // 2 - поточное управление
    pVarCounter =  CreateLocVar("nCounter",	CLocVar::vtInteger, "");   // счетчик тактов
    pVarStrNameControl =  CreateLocVar("strNameControl",	CLocVar::vtString, "control", true, "nControl");   // имя переменной режима работы
    string str = pVarStrNameControl->strGetDataSrc();
    if (str!= "") {
        pVarControl = GetAddressVar(str);
    }
    pVarStrNameStart =  CreateLocVar("strNameStart",	CLocVar::vtString, "start", true, "bStart");   // имя переменной режима работы
    str = pVarStrNameStart->strGetDataSrc();
    if (str!= "") {
        pVarStart = GetAddressVar(str);
    }
    pVarSleep = CreateLocVar("nSleep", CLocVar::vtInteger, "sleep", true, "1000");
    if (pVarControl->GetDataSrc() == 2) {
        bIfTrhread = true;          // поточное управление
    }

    pVarRed = CreateLocVar("bRed", CLocVar::vtBool, "");
//    pVarRed->bSerial = true;
    pVarYellow = CreateLocVar("bYellow", CLocVar::vtBool, "");
//    pVarYellow->bSerial = true;
    pVarGreen = CreateLocVar("bGreen", CLocVar::vtBool, "");
//    pVarGreen->bSerial = true;
    pVarStrInitColor = CreateLocVar("nInitColor", CLocVar::vtString, "", true, "Red");
//    pVarStrInitColor->bSerial = true;
//    pVarStrInitColor->SetDataSrc(nullptr, "Red", nullptr);
    string strClr = pVarStrInitColor->strGetDataSrc();

    pVarMaxCntr = CreateLocVar("max_cntr", CLocVar::vtInteger, "", true, "55");
    nCounter = 0;
    if (x1()) { nCounter = 0; }
    if (x2()) { nCounter = 50; }
    if (x3()) { nCounter = 35; }
    pVarCounter->SetDataSrc(nullptr, nCounter);
    pVarCounter->UpdateVariable();
    return true;
}

int FTrafficLight::x1() { return pVarStrInitColor->strGetDataSrc() == "Red"; }
int FTrafficLight::x2() { return pVarStrInitColor->strGetDataSrc() == "Yellow"; }
int FTrafficLight::x3() { return pVarStrInitColor->strGetDataSrc() == "Green"; }
int FTrafficLight::x4() { return pMainWindow->demoFSM; }
int FTrafficLight::x5() { return pVarStart->GetDataSrc(); }
int FTrafficLight::x11() { return pVarControl->GetDataSrc() == 0; }
int FTrafficLight::x13() { return pVarControl->GetDataSrc() == 1; }
int FTrafficLight::x14() { return pVarControl->GetDataSrc() == 2; }
int FTrafficLight::x12() { return pVarControl != nullptr && pVarStart; }

void FTrafficLight::y1() { pVarRed->SetDataSrc(nullptr, 0.0); }
void FTrafficLight::y2() { pVarRed->SetDataSrc(nullptr, 1.0); }
void FTrafficLight::y3() { pVarYellow->SetDataSrc(nullptr, 0.0); }
void FTrafficLight::y4() { pVarYellow->SetDataSrc(nullptr, 1.0); }
void FTrafficLight::y5() { pVarGreen->SetDataSrc(nullptr, 0.0); }
void FTrafficLight::y6() { pVarGreen->SetDataSrc(nullptr, 1.0); }

void FTrafficLight::y7() {
    if (!bIfTrhread) FCreateDelay(30000);
    else pThTrafficLights->msleep(30000);
}   // 30 sec
void FTrafficLight::y8() {
    if (!bIfTrhread) FCreateDelay(5000);
    else pThTrafficLights->msleep(5000);
}    // 5 sec
void FTrafficLight::y9() {
    if (!bIfTrhread) FCreateDelay(10000);
    else pThTrafficLights->msleep(10000);

}   // 10 sec
void FTrafficLight::y10() {
    if (!bIfTrhread) FCreateDelay(1000);
    else pThTrafficLights->msleep(1000);
}   // 1 sec
void FTrafficLight::y12() { FInit(); }
void FTrafficLight::y15() {
    if (x3()) {
        TimeMs = Timer.elapsed(); formatTime(TimeMs);
        Timer.start();
    }
}
void FTrafficLight::y16() {
    if (x1()) {
        TimeMs = Timer.elapsed(); formatTime(TimeMs);
        Timer.start();
    }
}

void FTrafficLight::y11() {
    FStop();
    nStateTimer = 11;
}

void FTrafficLight::y13() {
    int n = 0;
    if (pMainWindow->pVarSet->bIfSynchronousOperation) {
        n = pVarSleep->GetDataSrc();
        n = pMainWindow->pVarSet->dDeltaTime;
    }
    nIdTimer = startTimer(n - pMainWindow->nDeltaDelta);
}
void FTrafficLight::y21() {}
void FTrafficLight::y22() {}
void FTrafficLight::y23() {}
void FTrafficLight::y24() {
    nCounter = pVarCounter->GetDataSrc();
    if (nCounter == 0) { y2(); y3(); y5(); }
    else if (nCounter == 35) { y1(); y3(); y6(); }
}
void FTrafficLight::y32() { }

#include "mainwindow.h"
extern MainWindow *pMainWindow;
void FTrafficLight::y17() {
    string str= FGetNameProcess();
    QThread *pThread = thread();    // ссылка на текущий поток
    if (pThTrafficLights)
        delete pThTrafficLights;
    pThTrafficLights    = new ThTrafficLights(this, pMainWindow);
}

QString FTrafficLight::formatTime(qint64 milliseconds)
{
    qint64 totalSeconds = milliseconds / 1000;
    qint64 minutes = totalSeconds / 60;
    qint64 seconds = totalSeconds % 60;
    qint64 ms = milliseconds % 1000;

    QString qstr = QString("%1:%2.%3")
        .arg(minutes, 2, 10, QLatin1Char('0'))
        .arg(seconds, 2, 10, QLatin1Char('0'))
        .arg(ms, 3, 10, QLatin1Char('0'));
//    if (pCVarFSA->pVFsaDialog) {
//        static_cast<CDlgTrafficLight*>(pCVarFSA->pVFsaDialog)->ViewTime(qstr);
//    }

    return qstr;

}

void FTrafficLight::timerEvent(QTimerEvent* t) {
//    QThread *pThread = thread();    // ссылка на текущий поток
    // исполнять пока установлен признак работы потока
    // так не возникает ошибки при закрытии приложения
    // (установлено опытным путем)
//    bool b = bool(pVarIfHide->GetDataSrc());
//    if (b)
//        return;

    switch(nStateTimer) {
    case 11:
        y1(); nStateTimer=1; break;
    case 1:
        y3(); nStateTimer = 2; break;
    case 2:
        if (!x1()) { y3(); break; }
        break;
    }
}

string FTrafficLight::FGetState(int nNum) {
    if (nIdTimer!=0) {
        switch(nStateTimer) {
        case 11: return "t_st"; break;
        case 1: return "t_s1"; break;
        case 2: return "t_s2"; break;
        case 3: return "t_s3"; break;
        default: return "error state";
        }
    }
    else return LFsaAppl::FGetState(nNum);
};
// поток  поток  поток  поток  поток  поток  поток  поток  поток  поток  поток  поток  поток
ThTrafficLights::ThTrafficLights(FTrafficLight *p, QObject *parent) :
    QThread()
{
    pFTrafficLight = p;
    bIfRun = true;      // установить признак запуска/завершения потока
    start(QThread::IdlePriority);            // запустить поток
    nState = 11;
}
ThTrafficLights::~ThTrafficLights() {
    if (bIfRun) { bIfRun = false; quit(); wait(); }
    bIfRun = false; quit(); wait();
}

/*
    LArc("R",		"RY","--",	"y2y3y5y7"),	//R=1, 30sec
    LArc("RY",		"G","--",	"y4y8"),    	//G=1, Y=1, 5 sec
    LArc("G",		"G0","--",	"y1y3y6y9"),	//G=1, 10 sec
    LArc("G0",		"G1","--",	"y5y10"),		//G=0, 1 sec
    LArc("G1",		"G01","--",	"y6y10"),		//G=1, 1 sec
    LArc("G01",		"G10","--",	"y5y10"),		//G=0, 1 sec
    LArc("G10",		"G02","--",	"y6y10"),		//G=1, 1 sec
    LArc("G02",		"Y","--",	"y5y10"),		//G=0, 1 sec
    LArc("Y",		"R","--",	"y1y4y5y8"),	//Y=1, 5 sec
 */
// цикл исполнения потока
void ThTrafficLights::run()
{
    bIfStop = false;       // сбросить признак останова потока
    if (bIfExecuteStep) {
        switch(nState) {
        case 11:
            if (pFTrafficLight->x5()) { pFTrafficLight->y14(); nState=1; }
            break;
        case 1:
            if (pFTrafficLight->x4()) { pFTrafficLight->y14(); }
            else if (!pFTrafficLight->x4()) { nState = 11; }
            break;
        }
    }
/*

    int nSleep = 0;
    if (pMainWindow->pVarSet->bIfSynchronousOperation) {
        nSleep = pMainWindow->pVarSet->dDeltaTime;
    }
    while(bIfRun)  {
        if (pFTrafficLight->x4()&&pFTrafficLight->x5()&&bIfExecuteStep) {
            if (!pMainWindow->demoFSM) {
                bIfRun = false;
            }
            bIfExecuteStep = false;
            QThread *pThread = thread();    // ссылка на текущий поток
            if (pFTrafficLight->nCounter == 0) {
                pFTrafficLight->y2(); pFTrafficLight->y3();
                pFTrafficLight->y5(); pFTrafficLight->y16();
            }
            if (pFTrafficLight->nCounter == 30) { pFTrafficLight->y4(); }
            if (pFTrafficLight->nCounter == 35) {
                pFTrafficLight->y1(); pFTrafficLight->y3();
                pFTrafficLight->y6(); pFTrafficLight->y15();
            }
            if (pFTrafficLight->nCounter == 45) { pFTrafficLight->y5(); }
            if (pFTrafficLight->nCounter == 46) { pFTrafficLight->y6(); }
            if (pFTrafficLight->nCounter == 47) { pFTrafficLight->y5(); }
            if (pFTrafficLight->nCounter == 48) { pFTrafficLight->y6(); }
            if (pFTrafficLight->nCounter == 49) { pFTrafficLight->y5(); }
            if (pFTrafficLight->nCounter == 50) { pFTrafficLight->y4(); }
            msleep(nSleep);
            int n = pFTrafficLight->pVarCounter->GetDataSrc();
            n++;
            pFTrafficLight->pVarCounter->SetDataSrc(nullptr, n);
            if (pFTrafficLight->nCounter == pFTrafficLight->pVarMaxCntr->GetDataSrc()) {
                pFTrafficLight->nCounter=0;
                pFTrafficLight->pVarCounter->SetDataSrc(nullptr, n);
            }
        }
    }
*/
    bIfStop = true;        // установить признак останова потока
}
