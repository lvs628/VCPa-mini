#ifndef FCROSSWALK_H
#define FCROSSWALK_H


#include "lfsaappl.h"
#include <QElapsedTimer>  // Добавляем для измерения времени
#include <QObject>
#include <QThread>

class FCrosswalk;
class ThCrosswalk : public QThread
{
    Q_OBJECT
public:
    ThCrosswalk(FCrosswalk *p, QObject *parent);
    ~ThCrosswalk();
    QElapsedTimer TimerRun;
    bool bStart{true};
    int nState{0};
protected:
    bool bIfRun{false};
    bool bIfStop{false};
    bool bIfExecuteStep{false};
    FCrosswalk *pFCrosswalk{nullptr};
    void run();
friend class FCrosswalk;
};

extern LArc TBL_Crosswalk[];
class FCrosswalk : public QObject,
    public LFsaAppl
{
    Q_OBJECT
public:
    void virtual FResetActions();
    void ExecuteThreadStep();
    void WaitForThreadToFinish(QThread *obj, unsigned long time=500);

    void timerEvent(QTimerEvent* t);
    string FGetState(int nNum=-1);

    bool FCreationOfLinksForVariables();
    FCrosswalk(string strNam, LArc *pTBL=TBL_Crosswalk);
    virtual ~FCrosswalk(void);
    ThCrosswalk  *pThCrosswalk{nullptr};

    CVar    *pVarRed;
    CVar    *pVarGreen;
//
    CVar    *pVarStrNameStart;
    CVar    *pVarStrNameControl;
    CVar    *pVarControl{nullptr};
    CVar    *pVarSleep;
    CVar    *pVarMaxCntr;
    CVar    *pVarCounter;
    CVar    *pVarStart;

    QElapsedTimer Timer;
    QElapsedTimer   timeApp;
    qint64 TimeMs{0};
    string strTime{""};
    QString formatTime(qint64 milliseconds);  // Метод для форматирования времени
//
    int nIdTimer{0};
    int nStateTimer{0};         // состояние потока
    int nCounter{0};
protected:
    int x4(); int x5(); int x11(); int x12(); int x13(); int x14();
    void y1(); void y2(); void y3(); void y4(); void y5(); void y6(); void y7(); void y8();
//
    void y11(); void y12(); void y13();
    void y17();
    void y21(); void y22(); void y23();
    void y24();
    void y32();

    bool    bIfTrhread{false};
    int     nCadr{0};
friend class ThCrosswalk;
};

#endif // FCROSSWALK_H
