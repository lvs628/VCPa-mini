#ifndef FLIGHTEASY_H
#define FLIGHTEASY_H
#include "FTrafficLight.h"

class FLightEasy: public FTrafficLight
{
public:
    void timerEvent(QTimerEvent* t);

    void FResetActions();
    bool FCreationOfLinksForVariables();
    FLightEasy(string strNam = "FLightEasy");
    void    run();
protected:
    void y14();
};

#endif // FLIGHTEASY_H
