#ifndef FCOMMONDECODER_H
#define FCOMMONDECODER_H


#include "lfsaappl.h"

class FCommonDecoder :
    public LFsaAppl
{
public:
    bool FCreationOfLinksForVariables();
    FCommonDecoder(string strNam);
    virtual ~FCommonDecoder(void);
    CVar *pVarStrNameRed_1;
    CVar *pVarStrNameYellow_1;
    CVar *pVarStrNameGreen_1;
    CVar *pVarStrNameRed_2;
    CVar *pVarStrNameYellow_2;
    CVar *pVarStrNameGreen_2;
    CVar *pVarCode;
    CVar *pVarRed_1;
    CVar *pVarYellow_1;
    CVar *pVarGreen_1;
    CVar *pVarRed_2;
    CVar *pVarYellow_2;
    CVar *pVarGreen_2;
protected:
    int x1(); int x2(); int x3(); int x4(); int x5(); int x6(); int x12();
    void y1(); void y12();
};

#endif // FCOMMONDECODER_H
