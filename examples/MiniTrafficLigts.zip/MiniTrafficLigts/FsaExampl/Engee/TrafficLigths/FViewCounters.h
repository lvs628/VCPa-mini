#ifndef FVIEWCOUNTERS_H
#define FVIEWCOUNTERS_H


#include <QElapsedTimer>
#include "lfsaappl.h"

class FTrafficLight;
class FCrosswalk;
class FViewCounters :
    public LFsaAppl
{
public:
    LFsaAppl* Create(CVarFSA *pCVF) { return new FViewCounters(nameFsa); }
    bool FCreationOfLinksForVariables();
    FViewCounters(string strNam);
    virtual ~FViewCounters(void);
    CVar* pVarStrNameCrossWalk;
    CVar* pVarStrNameTrafficLight_1;
    CVar* pVarStrNameTrafficLight_2;
    CVar    *pVarStrNameStart;
    CVar    *pVarStart;

    FCrosswalk  *pFCrosswalk;
    FTrafficLight   *pFTrafficLight_1;
    FTrafficLight   *pFTrafficLight_2;

    long lNumberOfFrames{2};

protected:
    int x1(); int x4(); int x5(); int x12();
    void y1(); void y2(); void y3(); void y12();
    QElapsedTimer timeApp;
    unsigned long ulEndTime;

};

#endif // FVIEWCOUNTERS_H
