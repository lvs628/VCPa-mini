#include "stdafx.h"
#include "FCrossEasy.h"
#include <QTimerEvent>  // Добавляем для измерения времени

LArc TBL_CrossEasy[] = {
    LArc("xx",		"xx","^x12",  "y12"),   // есть указатель на переменную режима работы
    LArc("xx",		"ss","x12",   "y24"),   // есть

    LArc("ss",		"st","x11","y21"),      // автоматное управление->если параметры установлены -> переход в состояние s1
    LArc("ss",		"tt","x13", "y13y22"),  // таймерное управление->старт таймера
    LArc("ss",		"t2","x14","y23"),      // поточное управление ->

    LArc("tt",		"t1","x5",  "y11"),     // останов автомата, нач состояние switch
    LArc("t1",		"t1","--",  "--"),      // если параметры установлены -> переход в состояние s1

    LArc("t2",		"t3","x5",  "y17"),     // создание потока
    LArc("t3",		"t3","--",  "--"),      // крутимся

    LArc("st",		"s1","x5",  "y14"),     // если старт
    LArc("s1",		"s1","x4",  "y14"),     // реализуем диаграмму пропуска пешехода
    LArc("s1",		"st","^x4", "--"),      //
    LArc()
};

FCrossEasy::FCrossEasy(string strNam): FCrosswalk(strNam, TBL_CrossEasy)
{ }

void FCrossEasy::FResetActions() {
    FCrosswalk::FResetActions();
}

bool FCrossEasy::FCreationOfLinksForVariables() {
    FCrosswalk::FCreationOfLinksForVariables();
    pVarMaxCntr = CreateLocVar("max_cntr", CLocVar::vtInteger, "", true, "55");
    return true;
}
//
void FCrossEasy::y14() {
    nCounter = pVarCounter->GetDataSrc();
    if (nCounter == 0) { y2(); y3(); y8(); }
    else if (nCounter == 20) { y1(); y4(); }
    else if (nCounter == 30) { y2(); y3(); }
    nCounter++;
    int nMax = pVarMaxCntr->GetDataSrc();
    if (nCounter == nMax) { nCounter = 0; }
    pVarCounter->SetDataSrc(nullptr, nCounter);
}

void FCrossEasy::timerEvent(QTimerEvent* t) {
    if (nIdTimer != t->timerId())
        return;
    switch(nStateTimer) {
    case 11:
        if (x5()) { y14(); nStateTimer=1; }
        break;
    case 1:
        if (x4()) { y14(); }
        else if (!x4()) { nStateTimer = 11; }
        break;
    }
}

void FCrossEasy::run() { FCrosswalk::run(); }
