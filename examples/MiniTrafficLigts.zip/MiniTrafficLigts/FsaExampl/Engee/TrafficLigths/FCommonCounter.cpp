#include "FCommonCounter.h"

#include "stdafx.h"
#include "FCommonCounter.h"

static LArc TBL_CommonCounter[] = {
    LArc("cntr",    "cntr","x2",	"y1y2"),			//
    LArc("cntr",	"cntr","^x2",	"y2y3y4"),			//
    LArc()
};

FCommonCounter::FCommonCounter(string strNam):
    LFsaAppl(TBL_CommonCounter, strNam, nullptr)
{
    Timer.start();
}

FCommonCounter::~FCommonCounter(void)
{
}

bool FCommonCounter::FCreationOfLinksForVariables() {
    pVarCntr = CreateLocVar("cntr", CLocVar::vtInteger, "");
    pVarMaxCntr = CreateLocVar("max_cntr", CLocVar::vtInteger, "", "55");
    return true;
}

int FCommonCounter::x1() { return pVarCntr->GetDataSrc() <= pVarMaxCntr->GetDataSrc(); }
int FCommonCounter::x2() { return FIsActiveParDelay(); }
int FCommonCounter::x3() { return pVarCntr->GetDataSrc(); }

int FCommonCounter::x12() { return true; }

void FCommonCounter::y1() {
    int n = pVarCntr->GetDataSrc();
    pVarCntr->SetDataSrc(nullptr, ++n);
}
void FCommonCounter::y2() { FCreateDelay(1000); }
void FCommonCounter::y3() {
    pVarCntr->SetDataSrc(nullptr, 0.0);
    TimeMs = Timer.elapsed();
    formatTime(TimeMs);
    Timer.start();
}
void FCommonCounter::y4() {
    FCreateParDelay(55000);
}

void FCommonCounter::y12() { FInit(); }

QString FCommonCounter::formatTime(qint64 milliseconds)
{
    qint64 totalSeconds = milliseconds / 1000;
    qint64 minutes = totalSeconds / 60;
    qint64 seconds = totalSeconds % 60;
    qint64 ms = milliseconds % 1000;

    QString qstr = QString("%1:%2.%3")
        .arg(minutes, 2, 10, QLatin1Char('0'))
        .arg(seconds, 2, 10, QLatin1Char('0'))
        .arg(ms, 3, 10, QLatin1Char('0'));

//    if (pCVarFSA->pVFsaDialog) {
//        static_cast<CDlgCommonCounter*>(pCVarFSA->pVFsaDialog)->ViewTime(qstr);
//    }

    return qstr;

}
