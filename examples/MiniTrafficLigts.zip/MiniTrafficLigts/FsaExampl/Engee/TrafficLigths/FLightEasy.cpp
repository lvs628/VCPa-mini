#include "stdafx.h"
#include "FLightEasy.h"

LArc TBL_LightEasy[] = {
    LArc("xx",		"xx","^x12",  "y12"),   // есть указатель на переменную режима работы
    LArc("xx",		"ss","x12",   "y24"),   // есть

    LArc("ss",		"st","x11","y21"),      // автоматное управление->если параметры установлены -> переход в состояние s1
    LArc("ss",		"tt","x13", "y13y22"),  // таймерное управление->старт таймера
    LArc("ss",		"t2","x14","y23"),      // поточное управление ->

    LArc("tt",		"t1","x5",  "y11"),     // останов автомата, нач состояние switch
    LArc("t1",		"t1","--",  "--"),      // если параметры установлены -> переход в состояние s1

    LArc("t2",		"t3","x5",  "y17"),     // создание потока
    LArc("t3",		"t3","--",  "--"),      // крутимся

    LArc("st",		"s1","x5",  "y14y32"),     // реализуем диаграмму пропуска пешехода
    LArc("s1",		"s1","x4",  "y14"),     // реализуем диаграмму пропуска пешехода
    LArc("s1",		"st","^x4", "--"),     // реализуем диаграмму пропуска пешехода
    LArc()
};

FLightEasy::FLightEasy(string strNam):
    FTrafficLight(strNam, TBL_LightEasy)
{
}

void FLightEasy::FResetActions() {
    FTrafficLight::FResetActions();
}

bool FLightEasy::FCreationOfLinksForVariables() {
    FTrafficLight::FCreationOfLinksForVariables();
    return true;
}

void FLightEasy::y14() {
    nCounter = pVarCounter->GetDataSrc();
    if (nCounter == 0) { y2(); y3(); y5(); y16(); }
    else if (nCounter == 30) { y4(); }
    else if (nCounter == 35) { y1(); y3(); y6(); y15(); }
    else if (nCounter == 45) { y5(); }
    else if (nCounter == 46) { y6(); }
    else if (nCounter == 47) { y5(); }
    else if (nCounter == 48) { y6(); }
    else if (nCounter == 49) { y5(); }
    else if (nCounter == 50) { y4(); }
    nCounter++;
    if (nCounter == pVarMaxCntr->GetDataSrc()) { nCounter=0; }
    pVarCounter->SetDataSrc(nullptr, nCounter);
}

void FLightEasy::timerEvent(QTimerEvent* t) {
    switch(nStateTimer) {
    case 11:
        if (x5()) { y14(); nStateTimer=1; }
        break;
    case 1:
        if (x4()) { y14(); }
        else if (!x4()) { nStateTimer = 11; }
        break;
    }
}

void FLightEasy::run() {
    FTrafficLight::run();
}
