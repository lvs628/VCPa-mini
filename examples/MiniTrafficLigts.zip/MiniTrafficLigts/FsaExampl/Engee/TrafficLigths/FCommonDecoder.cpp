#include "stdafx.h"
#include "FCommonDecoder.h"

static LArc TBL_CommonDecoder[] = {
    LArc("st",		"st","^x12","y12"),
    LArc("st",		"s1","x12",	"--"),
    LArc("s1",		"s1","--",	"y1"),
    LArc()
};

FCommonDecoder::FCommonDecoder(string strNam):
    LFsaAppl(TBL_CommonDecoder, strNam, nullptr)
{
}

FCommonDecoder::~FCommonDecoder(void)
{
}

#include "FLightEasy.h"
#include "FCrossEasy.h"
#include "FCommonDecoder.h"
#include "mainwindow.h"
extern MainWindow *pMainWindow;
bool FCommonDecoder::FCreationOfLinksForVariables() {
    pVarStrNameRed_1 = CreateLocVar("strRed_1", CLocVar::vtString, "", true, "TrafficLight_1.bRed");
    pVarStrNameYellow_1 = CreateLocVar("strYelow_1", CLocVar::vtString, "", true, "TrafficLight_1.bYellow");
    pVarStrNameGreen_1 = CreateLocVar("strGreen_1", CLocVar::vtString, "", true, "TrafficLight_1.bGreen");
    pVarStrNameRed_2 = CreateLocVar("strRed_2", CLocVar::vtString, "", true, "TrafficLight_2.bRed");
    pVarStrNameYellow_2 = CreateLocVar("strYellow_2", CLocVar::vtString, "", true, "TrafficLight_2.bYellow");
    pVarStrNameGreen_2 = CreateLocVar("strGreen_2", CLocVar::vtString, "", true, "TrafficLight_2.bGreen");
    pVarRed_1   = pMainWindow->pFLightEasy_1->GetAddressVar(".bRed");
    pVarYellow_1= pMainWindow->pFLightEasy_1->GetAddressVar(".bYellow");
    pVarGreen_1 = pMainWindow->pFLightEasy_1->GetAddressVar(".bGreen");
    pVarRed_2   = pMainWindow->pFLightEasy_2->GetAddressVar(".bRed");
    pVarYellow_2= pMainWindow->pFLightEasy_2->GetAddressVar(".bYellow");
    pVarGreen_2 = pMainWindow->pFLightEasy_2->GetAddressVar(".bGreen");
//    pVarRed_1   = GetAddressVar(pVarStrNameRed_1->strGetDataSrc());
//    pVarYellow_1   = GetAddressVar(pVarStrNameYellow_1->strGetDataSrc());
//    pVarGreen_1= GetAddressVar(pVarStrNameGreen_1->strGetDataSrc());
//    pVarRed_2= GetAddressVar(pVarStrNameRed_2->strGetDataSrc());
//    pVarYellow_2= GetAddressVar(pVarStrNameYellow_2->strGetDataSrc());
//    pVarGreen_2= GetAddressVar(pVarStrNameGreen_2->strGetDataSrc());

    pVarCode = CreateLocVar("code", CLocVar::vtInteger, "");

    return true;
}

int FCommonDecoder::x1() { return pVarRed_1->GetDataSrc(); }
int FCommonDecoder::x2() { return pVarYellow_1->GetDataSrc(); }
int FCommonDecoder::x3() { return pVarGreen_1->GetDataSrc(); }
int FCommonDecoder::x4() { return pVarRed_2->GetDataSrc(); }
int FCommonDecoder::x5() { return pVarYellow_2->GetDataSrc(); }
int FCommonDecoder::x6() { return pVarGreen_2->GetDataSrc(); }

int FCommonDecoder::x12() { return pVarRed_1!=nullptr && pVarYellow_1 && pVarGreen_1
            && pVarRed_2 && pVarYellow_2 && pVarGreen_2; }

static int nCodeSav{-1};
void FCommonDecoder::y1() {
    bool bR_1 = pVarRed_1->GetDataSrc();
    bool bY_1 = pVarYellow_1->GetDataSrc();
    bool bG_1 = pVarGreen_1->GetDataSrc();
    bool bR_2 = pVarRed_2->GetDataSrc();
    bool bY_2 = pVarYellow_2->GetDataSrc();
    bool bG_2 = pVarGreen_2->GetDataSrc();
    if (!bR_1&&!bY_1&&!bG_1&&bR_2&&!bY_2&&!bG_2)        { pVarCode->SetDataSrc(this, 8.0); }
    else if (!bR_1&&!bY_1&&bG_1&&bR_2&&!bY_2&&!bG_2)    { pVarCode->SetDataSrc(this, 12.0); }
    else if (!bR_1&&bY_1&&!bG_1&&bR_2&&bY_2&&!bG_2)     { pVarCode->SetDataSrc(this, 22.0); }
    else if (bR_1&&!bY_1&&!bG_1&&!bR_2&&!bY_2&&!bG_2)   { pVarCode->SetDataSrc(this, 32.0); }
    else if (bR_1&&!bY_1&&!bG_1&&!bR_2&&!bY_2&&bG_2)    { pVarCode->SetDataSrc(this, 33.0); }
    else if (bR_1&&!bY_1&&!bG_1&&bR_2&&!bY_2&&!bG_2)    { pVarCode->SetDataSrc(this, 36.0); }
    else if (bR_1&&bY_1&&!bG_1&&bR_2&&!bY_2&&!bG_2)     { pVarCode->SetDataSrc(this, 52.0); }
    else if (bR_1&&!bY_1&&!bG_1&&!bR_2&&bY_2&&!bG_2)    { pVarCode->SetDataSrc(this, 34.0); }
/*
    if (!x1()&&!x2()&&!x3()&&x4()&&!x5()&&!x6())       { pVarCode->SetDataSrc(this, 8.0); }
    else if (!x1()&&!x2()&&x3()&&x4()&&!x5()&&!x6())    { pVarCode->SetDataSrc(this, 12.0); }
    else if (!x1()&&x2()&&!x3()&&x4()&&x5()&&!x6())    { pVarCode->SetDataSrc(this, 22.0); }
    else if (x1()&&!x2()&&!x3()&&!x4()&&!x5()&&!x6())   { pVarCode->SetDataSrc(this, 32.0); }
    else if (x1()&&!x2()&&!x3()&&!x4()&&!x5()&&x6())    { pVarCode->SetDataSrc(this, 33.0); }
    else if (x1()&&!x2()&&!x3()&&x4()&&!x5()&&!x6())    { pVarCode->SetDataSrc(this, 36.0); }
    else if (x1()&&x2()&&!x3()&&x4()&&!x5()&&!x6())     { pVarCode->SetDataSrc(this, 52.0); }
    else if (x1()&&!x2()&&!x3()&&!x4()&&x5()&&!x6())    { pVarCode->SetDataSrc(this, 34.0); }
*/
/*
    int nCode = pVarCode->GetDataSrc();
    if (nCode != nCodeSav) {
        qDebug()<<"Code="<<pVarCode->GetDataSrc();
        nCodeSav = nCode;
    }
*/
}

void FCommonDecoder::y12() { FInit(); }
