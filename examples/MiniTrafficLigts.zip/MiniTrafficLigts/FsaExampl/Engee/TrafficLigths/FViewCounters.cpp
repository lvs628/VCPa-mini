#include "stdafx.h"
#include "FViewCounters.h"
#include "FCrossEasy.h"
#include "FCrosswalk.h"
#include "FLightEasy.h"
#include "mainwindow.h"

extern MainWindow *pMainWindow;

static LArc TBL_ViewCounters[] = {
    LArc("st",		"st","^x12",	"y12"),			//
    LArc("st",		"s1","x12",     "--"),			//
    LArc("s1",		"s2","x4x5",    "y2"),			//
    LArc("s2",		"s2","x4",      "y1"),			//
    LArc("s2",		"s1","^x4",     "y3"),			//
    LArc()
};

FViewCounters::FViewCounters(string strNam):
    LFsaAppl(TBL_ViewCounters, strNam, nullptr)
{
}

FViewCounters::~FViewCounters(void)
{
}

bool FViewCounters::FCreationOfLinksForVariables() {
    pVarStrNameCrossWalk = CreateLocVar("strNameCrosswalk", CLocVar::vtString, "", true, "CrossEasy");
    pVarStrNameTrafficLight_1 = CreateLocVar("strNameTrafficLight_1", CLocVar::vtString, "", true, "LightEasy_1");
    pVarStrNameTrafficLight_2 = CreateLocVar("strNameTrafficLight_2", CLocVar::vtString, "", true, "LightEasy_2");

    string str = pVarStrNameCrossWalk->strGetDataSrc();
    if (str != "") pFCrosswalk = static_cast<FCrosswalk*>(FGetPtrFsaAppl(str));
    else pFCrosswalk = static_cast<FCrosswalk*>(FGetPtrFsaAppl("CrossEasy"));

    str = pVarStrNameTrafficLight_1->strGetDataSrc();
    if (str != "") pFTrafficLight_1 = static_cast<FLightEasy*>(FGetPtrFsaAppl(str));
    else pFTrafficLight_1 = static_cast<FLightEasy*>(FGetPtrFsaAppl("LightEasy_1"));

    str = pVarStrNameTrafficLight_2->strGetDataSrc();
    if (str != "") pFTrafficLight_2 = static_cast<FLightEasy*>(FGetPtrFsaAppl(str));
    else pFTrafficLight_2 = static_cast<FLightEasy*>(FGetPtrFsaAppl("LightEasy_2"));

    pVarStrNameStart =  CreateLocVar("strNameStart",	CLocVar::vtString, "start", true, "bStart");   // имя переменной режима работы
    str = pVarStrNameStart->strGetDataSrc();
    if (str!= "") {
        pVarStart = GetAddressVar(str);
    }

    return true;
}

int FViewCounters::x1() { return false; }
int FViewCounters::x4() { return pMainWindow->demoFSM; }
int FViewCounters::x5() { return pVarStart->GetDataSrc(); }
int FViewCounters::x12(){ return pFCrosswalk!=nullptr&&pFTrafficLight_1&&pFTrafficLight_2&&pVarStart; }

void FViewCounters::y1() {
    if (pMainWindow->bIfViewCounters) {
        qDebug()<<"Counters:"<<pFCrosswalk->pVarCounter->GetDataSrc()<<","<<pFTrafficLight_1->pVarCounter->GetDataSrc()<<","
                  <<pFTrafficLight_2->pVarCounter->GetDataSrc();
    }
}

void FViewCounters::y2() {
    timeApp.start();
}

void FViewCounters::y3() {
    ulEndTime = timeApp.elapsed();
//    qDebug()<<"ulEndTime="<<ulEndTime;
}

void FViewCounters::y12() { FInit(); }
