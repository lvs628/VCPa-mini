#ifndef FVIEWCROSSWALK_H
#define FVIEWCROSSWALK_H

#include "lfsaappl.h"

extern LArc TBL_ViewCrosswalk[];
class FCrosswalk;
class FViewCrosswalk :
        public LFsaAppl
{
public:
    bool FCreationOfLinksForVariables();
    FViewCrosswalk(string strNam, LArc *pTBL=TBL_ViewCrosswalk);
    virtual ~FViewCrosswalk(void);
    CVar* pVarStrNameAppl;
    FCrosswalk  *pFCrosswalk{nullptr};
protected:
    int x4(); int x12();
    void y1(); void y12();
};

#endif // FVIEWCROSSWALK_H
