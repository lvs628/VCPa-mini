#ifndef FTRAFFICLIGHT_H
#define FTRAFFICLIGHT_H


#include "lfsaappl.h"
#include <QElapsedTimer>  // Добавляем для измерения времени
#include <QObject>
#include <QThread>

class FTrafficLight;
class ThTrafficLights : public QThread
{
    Q_OBJECT
public:
    ThTrafficLights(FTrafficLight *p, QObject *parent);
    ~ThTrafficLights();
    int nState{0};
protected:
    bool bIfRun{false};
    bool bIfStop{false};
    bool bIfExecuteStep{false};
    FTrafficLight *pFTrafficLight{nullptr};
    void run();
friend class FTrafficLight;
};

extern LArc TBL_TrafficLight[];
class FTrafficLight : public QObject,
    public LFsaAppl
{
    Q_OBJECT
public:
    void FResetActions();
    void ExecuteThreadStep();
    void WaitForThreadToFinish(QThread *obj, unsigned long time=500);

    void timerEvent(QTimerEvent* t);
    string FGetState(int nNum=-1);

    bool FCreationOfLinksForVariables();
    FTrafficLight(string strNam, LArc *pTBL=TBL_TrafficLight);
    virtual ~FTrafficLight(void);
    ThTrafficLights  *pThTrafficLights{nullptr};
    CVar    *pVarRed;
    CVar    *pVarYellow;
    CVar    *pVarGreen;
    CVar    *pVarStrInitColor;
    CVar    *pVarMaxCntr;
    CVar    *pVarCounter;
//
    CVar    *pVarStrNameStart;
    CVar    *pVarStrNameControl;
    CVar    *pVarControl;
    CVar    *pVarSleep;
    CVar    *pVarStart;

    QElapsedTimer Timer;
    qint64 TimeMs{0};
    QString formatTime(qint64 milliseconds);  // Метод для форматирования времени
//
    int nIdTimer{0};
    int nStateTimer{0};         // состояние потока
    int nCounter{0};
protected:
    int x1(); int x2(); int x3(); int x4(); int x5(); int x11(); int x12(); int x13(); int x14();
    void y1(); void y2(); void y3(); void y4(); void y5(); void y6();
    void y7(); void y8(); void y9(); void y10();
    void y15(); void y16();
    void y12();
//
    void y11(); void y13();
    void y17();
    void y21(); void y22(); void y23();
    void y24();
    void y32();
    bool bIfTrhread{false};
friend class ThTrafficLights;
};

#endif // FTRAFFICLIGHT_H
