#include "stdafx.h"
#include "FCrosswalk.h"
#include "mainwindow.h"
#include "FLightEasy.h"

extern MainWindow *pMainWindow;

LArc TBL_Crosswalk[] = {
    LArc("xx",		"xx","^x12",    "y12"), // есть указатель на переменную режима работы
    LArc("xx",		"ss","x12x5",   "y24"),  // есть

    LArc("ss",		"tt","x11^x13^x14", "y13y21"),  // 0 - автоматное управление
    LArc("ss",		"R","^x11x13^x14",  "y22"),     // 1 - таймерное управление, на таймерное управление, старт таймера
    LArc("ss",		"t2","^x11^x13x14", "y23"),     // 2 - поточное управление, на автоматное управление

    LArc("tt",		"t1","--",  "y11"),     // останов автомата
    LArc("t1",		"t1","--",  "--"),      //

    LArc("t2",		"t3","--",  "y17"),     // останов автомата
    LArc("t3",		"t3","--",  "--"),      //

    LArc("R",   "G","x4",	"y2y3y5y8"),    // Red      - 20sec
    LArc("G",	"R1","x4",	"y1y4y6"),      // Green    - 10 sec
    LArc("R1",	"R","x4",	"y2y3y7"),		// Red      - 25 sec
    LArc()
};

FCrosswalk::FCrosswalk(string strNam, LArc *pTBL):
    QObject(),
    LFsaAppl(pTBL, strNam, nullptr)
{
    Timer.start();
    nCadr = 0;
}

FCrosswalk::~FCrosswalk(void) {
    if (pThCrosswalk) delete pThCrosswalk;
    pThCrosswalk = nullptr;
    WaitForThreadToFinish(pThCrosswalk);
}

void FCrosswalk::FResetActions(){
    nCadr = 0;
    nCounter = 0;
    pVarCounter->SetDataSrc(nullptr, nCounter);
    pVarCounter->UpdateVariable();
    if (pThCrosswalk) delete pThCrosswalk;
    pThCrosswalk = nullptr;
}

void FCrosswalk::ExecuteThreadStep() {
    if (pThCrosswalk)
        pThCrosswalk->bIfExecuteStep = true;
}

void FCrosswalk::WaitForThreadToFinish(QThread *obj, unsigned long time) {
    if (obj) {
        // завершить поток
        pThCrosswalk->bIfRun = false;
        pThCrosswalk->quit();
        pThCrosswalk->wait(time);
        pThCrosswalk->terminate();
    }
    delete obj;
}

bool FCrosswalk::FCreationOfLinksForVariables() {
// 0 - таймерное управление
// 1 - автоматное управление
// 2 - поточное управление
    pVarStrNameControl =  CreateLocVar("strNameControl",	CLocVar::vtString, "control", true, "nControl");   // имя переменной режима работы
    string str = pVarStrNameControl->strGetDataSrc();
    if (str!= "") { pVarControl = GetAddressVar(str); }
    if (pVarControl) {
        int n = pVarControl->GetDataSrc();
        if (n == 2) {
            bIfTrhread = true;          // поточное управление
        }
    }
    pVarCounter =  CreateLocVar("nCounter",	CLocVar::vtInteger, "");   // счетчик тактов
    pVarStrNameStart =  CreateLocVar("strNameStart",	CLocVar::vtString, "start", true, "bStart");   // имя переменной режима работы
    str = pVarStrNameStart->strGetDataSrc();
    if (str!= "") { pVarStart = GetAddressVar(str); }
    pVarSleep = CreateLocVar("nSleep", CLocVar::vtInteger, "sleep", true, "1000");
    pVarMaxCntr = CreateLocVar("max_cntr", CLocVar::vtInteger, "", true, "55");
    pVarRed = CreateLocVar("bRed", CLocVar::vtBool, "");
    pVarGreen = CreateLocVar("bGreen", CLocVar::vtBool, "");
    return true;
}

int FCrosswalk::x4() { return pMainWindow->demoFSM; }
int FCrosswalk::x5() { return pVarStart->GetDataSrc(); }
int FCrosswalk::x11() { return pVarControl->GetDataSrc() == 0; }
int FCrosswalk::x12() { return pVarControl != nullptr && pVarStart; }
int FCrosswalk::x13() { return pVarControl->GetDataSrc() == 1; }
int FCrosswalk::x14() { return pVarControl->GetDataSrc() == 2; }

void FCrosswalk::y1() { pVarRed->SetDataSrc(nullptr, 0.0); }    // R-0
void FCrosswalk::y2() { pVarRed->SetDataSrc(nullptr, 1.0); }    // R=1
void FCrosswalk::y3() { pVarGreen->SetDataSrc(nullptr, 0.0); }  // G=0
void FCrosswalk::y4() { pVarGreen->SetDataSrc(nullptr, 1.0); }  // G=1
void FCrosswalk::y5() {
    if (!bIfTrhread) FCreateDelay(20000);
    else pThCrosswalk->msleep(20000);
}  // 20 sec
void FCrosswalk::y6() {
    if (!bIfTrhread) FCreateDelay(10000);
    else pThCrosswalk->msleep(10000);
}  // 10 sec
void FCrosswalk::y7() {
    if (!bIfTrhread) FCreateDelay(25000);
    else pThCrosswalk->msleep(25000);
}  // 25 sec
void FCrosswalk::y8() {
    if (nCadr < pMainWindow->lNumberOfFrames) {
        if (!pVarStart->GetDataSrc()) {
            nCadr++;
            TimeMs = Timer.elapsed();
            strTime = formatTime(TimeMs).toStdString();
            nCounter = pVarCounter->GetDataSrc();
            qDebug()<<nCadr<<")"<<FGetNameVarFSA().c_str()<<"="<<strTime.c_str();
            pMainWindow->ViewTime(strTime.c_str());
            Timer.start();
            pVarStart->SetDataSrc(nullptr, 0.0);
//            pVarStart->UpdateVariable();
            pMainWindow->nTheNumberOfTheCurrentFrame++;
            if (nCadr == pMainWindow->lNumberOfFrames) {
                qDebug()<<"Time App:"<<FGetNameVarFSA().c_str()<<"="<<timeApp.elapsed();
                pMainWindow->demoFSM = false;
            }
        }
        else {
            Timer.start();
            pVarStart->SetDataSrc(nullptr, 0.0);
            timeApp.start();
        }
    }
}

void FCrosswalk::y11() { FStop(); nStateTimer = 11; }

void FCrosswalk::y12() { FInit(); }

void FCrosswalk::y13() {
    int n = 0;
    if (pMainWindow->pVarSet->bIfSynchronousOperation) {
        n = pVarSleep->GetDataSrc();
        n = pMainWindow->pVarSet->dDeltaTime;
    }
    nIdTimer = startTimer(n-pMainWindow->nDeltaDelta);
}
void FCrosswalk::y17() {
    QThread *pThread = thread();    // ссылка на текущий поток
    pThCrosswalk    = new ThCrosswalk(this, pMainWindow);
}
void FCrosswalk::y21() {}
void FCrosswalk::y22() {}
void FCrosswalk::y23() {}
void FCrosswalk::y24() { y2(); y3(); }
void FCrosswalk::y32() { }

QString FCrosswalk::formatTime(qint64 milliseconds)
{
    qint64 totalSeconds = milliseconds / 1000;
    qint64 minutes = totalSeconds / 60;
    qint64 seconds = totalSeconds % 60;
    qint64 ms = milliseconds % 1000;

    QString qstr = QString("%1:%2.%3")
        .arg(minutes, 2, 10, QLatin1Char('0'))
        .arg(seconds, 2, 10, QLatin1Char('0'))
        .arg(ms, 3, 10, QLatin1Char('0'));
    return qstr;
}

void FCrosswalk::timerEvent(QTimerEvent* t) { }

string FCrosswalk::FGetState(int nNum) {
    if (nIdTimer!=0) {
        switch(nStateTimer) {
        case 11: return "t_ss"; break;
        case 1: return "t_R"; break;
        case 2: return "t_G"; break;
        case 3: return "t_R1"; break;
        default: return "error state";
        }
    }
    else return LFsaAppl::FGetState(nNum);
};
// поток  поток  поток  поток  поток  поток  поток  поток  поток  поток  поток  поток  поток
ThCrosswalk::ThCrosswalk(FCrosswalk *p, QObject *parent) :
    QThread()
{
    pFCrosswalk = p;
    bIfRun = true;      // установить признак запуска/завершения потока
    start(QThread::IdlePriority);            // запустить поток
    nState = 11;
}
ThCrosswalk::~ThCrosswalk() {
    if (bIfRun) { bIfRun = false; quit(); wait(); }
    bIfRun = false; quit(); wait();
}

/*
    LArc("R",   "G","--",	"y2y3y5y8"),    // Red      - 20sec
    LArc("G",	"R1","--",	"y1y4y6"),      // Green    - 10 sec
    LArc("R1",	"R","--",	"y2y3y7"),		// Red      - 25 sec
 */
// цикл исполнения потока
void ThCrosswalk::run()
{
    bIfStop = false;       // сбросить признак останова потока
    int nSleep = 0;
    if (pMainWindow->pVarSet->bIfSynchronousOperation) {
        nSleep = pMainWindow->pVarSet->dDeltaTime;
    }
    while(bIfRun)  {
        if (bIfExecuteStep) {
            bIfExecuteStep = 0;
            if (pFCrosswalk->x5()) {
                while (pFCrosswalk->x4()) {
                    if (bIfExecuteStep) {
                        bIfExecuteStep = 0;
                        if (pFCrosswalk->nCounter == 0) {
                            pFCrosswalk->y2();
                            pFCrosswalk->y3();
                            pFCrosswalk->y8();
                        }
                        if (pFCrosswalk->nCounter == 20) {
                            pFCrosswalk->y1();
                            pFCrosswalk->y4();
                        }
                        if (pFCrosswalk->nCounter == 30) {
                            pFCrosswalk->y2(); pFCrosswalk->y3();
                        }
                        msleep(nSleep-pMainWindow->nDeltaDelta);
                        pFCrosswalk->nCounter++;
                        if (pFCrosswalk->nCounter == pFCrosswalk->pVarMaxCntr->GetDataSrc()) {
                            pFCrosswalk->nCounter=0;
                        }
                    }
                }
            }
        }
    }
    bIfStop = true;        // установить признак останова потока
/*
            switch(nState) {
            case 11:
                if (pFCrosswalk->x5()) {
                    pFCrosswalk->y14();
                    nState=1;
                }
                break;
            case 1:
                if (pFCrosswalk->x4()) { pFCrosswalk->y14(); }
                else if (!pFCrosswalk->x4()) { nState = 11; }
                break;
            }
*/
/*
        if (pFCrosswalk->x4() && pFCrosswalk->x5() && bIfExecuteStep) {
            if (!bStart && pMainWindow->demoFSM) {
                int nt = TimerRun.elapsed();
    //            qDebug()<<pFCrosswalk->nCadr<<":"<<"run="<<nt<<"nCounter="<<pFCrosswalk->nCounter;
                TimerRun.start();
            }
            else {
                TimerRun.start();
                bStart = false;
            }
            if (!pMainWindow->demoFSM) {
                bIfRun = false;
            }

            bIfExecuteStep = false;
            QThread *pThread = thread();    // ссылка на текущий поток
            if (pFCrosswalk->nCounter == 0) {
                pFCrosswalk->y2();
                pFCrosswalk->y3();
                pFCrosswalk->y8();
            }
            if (pFCrosswalk->nCounter == 20) {
                pFCrosswalk->y1();
                pFCrosswalk->y4();
            }
            if (pFCrosswalk->nCounter == 30) {
                pFCrosswalk->y2(); pFCrosswalk->y3();
            }
            msleep(nSleep);
            pFCrosswalk->nCounter++;
            if (pFCrosswalk->nCounter == pFCrosswalk->pVarMaxCntr->GetDataSrc()) {
                pFCrosswalk->nCounter=0;
            }
        }
    }
*/
}
