#include "stdafx.h"
#include "FViewCrosswalk.h"
#include "FCrosswalk.h"
#include "mainwindow.h"

extern MainWindow *pMainWindow;

LArc TBL_ViewCrosswalk[] = {
    LArc("st",  "st","^x12","y12"),
    LArc("st",  "s1","x12",	"y1"),
    LArc("s1",  "s1","x4",  "y1"),
    LArc()
};

FViewCrosswalk::FViewCrosswalk(string strNam, LArc *pTBL):
    LFsaAppl(pTBL, strNam, nullptr)
{
}

FViewCrosswalk::~FViewCrosswalk(void) { }

bool FViewCrosswalk::FCreationOfLinksForVariables() {
    pVarStrNameAppl = CreateLocVar("strNameAppl", CLocVar::vtString, "", true, "CrossEasy");
    pFCrosswalk = static_cast<FCrosswalk*>(FGetPtrFsaAppl(pVarStrNameAppl->strGetDataSrc().c_str()));
    return true;
}

int FViewCrosswalk::x4() { return pMainWindow->demoFSM; }
int FViewCrosswalk::x12() { return pFCrosswalk != nullptr; }

void FViewCrosswalk::y1() {
//    QString qstr = pFCrosswalk->formatTime(pFCrosswalk->TimeMs);
//    pMainWindow->ViewTime(qstr);
}

void FViewCrosswalk::y12() { }
