#include "mainwindow.h"
#include "ui_mainwindow.h"

#include "FLightEasy.h"
#include "FCrossEasy.h"
#include "FCommonDecoder.h"
#include "FViewCrosswalk.h"
#include "DlgCrosswalk.h"
#include "FTestAppl.h"
#include "FViewCounters.h"

int nSavStep=-1;
unsigned long StopSequenceTime;
unsigned long ulEndTime;

extern MainWindow *pMainWindow;
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    // создаем среду исполнения автоматов
    pTAppProcesses = VCPaCore_init();

    startTimer(0);           // запускаем дискретное время среды
    bStart = true;

    QString qstr = QString::number(nDeltaTime);
    ui->IDC_EDT_DeltaTime->setText(qstr);
    ui->IDC_EDT_DeltaDelta->setText(QString::number(nDeltaDelta));
    ui->IDC_CHK_ViewCounters->setChecked(bIfViewCounters);
    ui->IDC_EDT_NumberOfFrames->setText(QString::number(lNumberOfFrames));
}

MainWindow::~MainWindow()
{
    delete ui;
    if (pTAppProcesses) VCPaCore_delete();
}

int nSavCntrEasy=-1;
void MainWindow::timerEvent(QTimerEvent* t) {
    int nId = t->timerId();
    VCPaCore_TimerEvent(nId);                                           // исполняем одиин такт среды
//
    ui->IDC_RADIO_Red->setChecked(pFLightEasy_1->pVarRed->GetDataSrc());
    ui->IDC_RADIO_Yellow->setChecked(pFLightEasy_1->pVarYellow->GetDataSrc());
    ui->IDC_RADIO_Green->setChecked(pFLightEasy_1->pVarGreen->GetDataSrc());

    ui->IDC_RADIO_Red_2->setChecked(pFLightEasy_2->pVarRed->GetDataSrc());
    ui->IDC_RADIO_Yellow_2->setChecked(pFLightEasy_2->pVarYellow->GetDataSrc());
    ui->IDC_RADIO_Green_2->setChecked(pFLightEasy_2->pVarGreen->GetDataSrc());

    bool bRed = pFCrossEasy->pVarRed->GetDataSrc();
    bool bGreen = pFCrossEasy->pVarGreen->GetDataSrc();
    ui->IDC_RADIO_Red_3->setChecked(bRed);
    ui->IDC_RADIO_Green_3->setChecked(bGreen);
    ui->IDC_EDT_Code->setText(QString::number(pFCommonDecoder->pVarCode->GetDataSrc()));

    ui->IDC_EDT_Count->setText(QString::number(pFCrossEasy->nCounter));

    ui->IDC_EDT_Count_TL_1->setText(QString::number(pFLightEasy_1->nCounter));
    ui->IDC_EDT_Count_TL_2->setText(QString::number(pFLightEasy_2->nCounter));
    ui->IDC_EDT_Count_CW->setText(QString::number(pFCrossEasy->nCounter));
}

void MainWindow::ViewTime(QString qstrT) {
    ui->IDC_EDT_Time->setText(qstrT);
}

#include "tappdrv.h"
void MainWindow::LoadingVariables()
{
    int nSize = pTAppProcesses->pTAppDrv->pSetVarRead->pArray->size();
    string strVar = "nControl;;0;0;0;0;;2;3;;;;;;;;;;2;0;0;0;0;0;0;0;0;0;"; // инициализация = 2
    TVarRead varControl(pTAppProcesses->pTAppDrv,strVar);
    TVarRead *var = pTAppProcesses->pTAppDrv->pSetVarRead->GetAddressVar("nControl");
    bool bAdd = false;
    if (!var) {
        var = &varControl;
        bAdd = true;
    }
    if (var->bIfInit) {
        if (var->unTypeVar == CVar::vtString) {
            var->SetDataSrc(nullptr, var->strInitValue, nullptr);
            var->UpdateVariable();
        }
        else {
            string sss;
            if (var->unTypeVar == CVar::vtFsastate) {
                sss = var->strng;
            }
            double d = QString(var->strInitValue.c_str()).toDouble();
            var->SetDataSrc(nullptr, d);
            var->UpdateVariable();
            if (var->unTypeVar == CVar::vtFsastate) {
                var->strng = sss;
            }
        }
    }
    if (bAdd) {
        pTAppProcesses->pTAppDrv->pSetVarRead->pArray->push_back(*var);
    }
    string strVarStart = "bStart;;0;0;0;0;;1;3;;;;;;;;;;2;0;0;0;0;0;0;0;0;0;"; // нет инициализации
    TVarRead varStrt(pTAppProcesses->pTAppDrv,strVarStart);
    TVarRead *varStart = pTAppProcesses->pTAppDrv->pSetVarRead->GetAddressVar("bStart");
    bAdd = false;
    if (!varStart) {
        varStart = &varStrt;
        bAdd = true;
    }
    if (varStart->bIfInit) {
        if (varStart->unTypeVar == CVar::vtString) {
            varStart->SetDataSrc(nullptr, var->strInitValue, nullptr);
            varStart->UpdateVariable();
        }
        else {
            string sss;
            if (varStart->unTypeVar == CVar::vtFsastate) {
                sss = varStart->strng;
            }
            double d = QString(varStart->strInitValue.c_str()).toDouble();
            varStart->SetDataSrc(nullptr, d);
            varStart->UpdateVariable();
            if (varStart->unTypeVar == CVar::vtFsastate) {
                varStart->strng = sss;
            }
        }
    }
    if (bAdd)
        pTAppProcesses->pTAppDrv->pSetVarRead->pArray->push_back(*varStart);
    nSize = pTAppProcesses->pTAppDrv->pSetVarRead->pArray->size();
}

void MainWindow::SetParameters() {
//======================================================================================
//======================================================================================
//======================================================================================
    string str = "Setting1";
    pVarSet = pTAppProcesses->pSetVarSetting->GetAddressVar(str);
#ifdef IF_ASYNCHRONOUS_MODE
    pVarSet->bIfSynchronousOperation = 0;
#else
    pVarSet->bIfSynchronousOperation = 1;
#endif
    if (pVarSet->bIfSynchronousOperation) {
      #if defined(IF_USING_FSM_MAX_SPEED)
//        nDeltaTime = 100;
      #else
//        nDeltaTime = 1000;
      #endif
    }
    if (pVarSet) { pVarSet->dDeltaTime = nDeltaTime - nDeltaDelta; }
    timeApp.start();
//    lNumberOfFrames = 2;                // число кадров
    CVar *pVar =  pTAppProcesses->pTAppDrv->pSetVarRead->GetAddressVar("nControl");
    int n = 0;
    n = pVar->GetDataSrc();
    if (pVar) {
        pVar->SetDataSrc(nullptr, pMainWindow->nOperatingMode);   // 0 - автоматное управление
//        pVar->SetDataSrc(nullptr, 1);   // 1 -  таймерное управление
//        pVar->SetDataSrc(nullptr, 2);   // 2 - поточное управление
        pVar->UpdateVariable();
        n = pVar->GetDataSrc();
        if (pVarSet->bIfSynchronousOperation) {
            if (n==0) qDebug()<<"Автоматное управление светофорами("<<pVarSet->dDeltaTime<<"msec,"<<lNumberOfFrames<<")";
            if (n==1) qDebug()<<"Таймерное управление светофорами("<<pVarSet->dDeltaTime<<"msec,"<<lNumberOfFrames<<")";
            if (n==2) qDebug()<<"Поточное управление светофорами("<<pVarSet->dDeltaTime<<"msec,"<<lNumberOfFrames<<")";
        }
        else {
            if (n==0) qDebug()<<"Автоматное управление светофорами(0,"<<lNumberOfFrames<<")";
            if (n==1) qDebug()<<"Таймерное управление светофорами(0),"<<lNumberOfFrames<<")";
            if (n==2) qDebug()<<"Поточное управление светофорами(0),"<<lNumberOfFrames<<")";
        }

    }
    if (!pVarStart) pVarStart = pTAppProcesses->pTAppDrv->pSetVarRead->GetAddressVar("bStart");
    if (pVarStart) {
        bool bStart = pVarStart->GetDataSrc();
        if (bStart) {
            pVarStart->SetDataSrc(nullptr, 0.0);
            pVarStart->UpdateVariable();
        }
    }
//======================================================================================
//======================================================================================
//======================================================================================
}

void MainWindow::LoadingProsesses()
{
    LoadingVariables();
    ui->IDC_EDT_OperatingMode->setText(QString::number(pMainWindow->nOperatingMode));
    if (pMainWindow->nOperatingMode == 0) ui->IDC_TXT_OperatingMode->setText("Автоматное управление");
    if (pMainWindow->nOperatingMode == 1) ui->IDC_TXT_OperatingMode->setText("Таймерное управление");
    if (pMainWindow->nOperatingMode == 2) ui->IDC_TXT_OperatingMode->setText("Поточное управление");

/*
    pFCrosswalk = new FCrosswalk("FCrosswalk");
    string vFSACrosswalk = "Crosswalk;FCrosswalk;Crosswalk;0;0;0;0;MaxSpeed;1;1";
    static CVarFSA varCrosswalk(pTAppProcesses,vFSACrosswalk);
    varCrosswalk.pLFsaAppl = pFCrosswalk;
    pTAppProcesses->pSetVarFSA->Add(varCrosswalk);
*/

    pFLightEasy_1 = new FLightEasy("FLightEasy");
    string vFSALightEasy_1 = "LightEasy_1;FLightEasy;LightEasy_1;0;0;0;0;InitFsaWorld;1;1";
    static CVarFSA varLightEasy_1(pTAppProcesses,vFSALightEasy_1);
    varLightEasy_1.pLFsaAppl = pFLightEasy_1;
    pTAppProcesses->pSetVarFSA->Add(varLightEasy_1);

    pFLightEasy_2 = new FLightEasy("FLightEasy");
    string vFSALightEasy_2 = "LightEasy_2;FLightEasy;LightEasy_2;0;0;0;0;InitFsaWorld;1;1";
    static CVarFSA varLightEasy_2(pTAppProcesses,vFSALightEasy_2);
    varLightEasy_2.pLFsaAppl = pFLightEasy_2;
    pTAppProcesses->pSetVarFSA->Add(varLightEasy_2);

    pFCrossEasy = new FCrossEasy("FCrossEasy");
    string vFSACrossEasy = "CrossEasy;FCrossEasy;CrossEasy;0;0;0;0;InitFsaWorld;1;1";
    static CVarFSA varCrossEasy(pTAppProcesses,vFSACrossEasy);
    varCrossEasy.pLFsaAppl = pFCrossEasy;
    pTAppProcesses->pSetVarFSA->Add(varCrossEasy);

    pCDlgCrosswalk = new CDlgCrosswalk("CDlgCrosswalk", TBL_DlgCrosswalk, pMainWindow);
    pCDlgCrosswalk->pFCrosswalk = pFCrossEasy;
    string vFSADlgCrosswalk = "DlgCrosswalk;CDlgCrosswalk;DlgCrosswalk;0;0;0;0;SysDlg;1;1";
    static CVarFSA varDlgCrosswalk(pTAppProcesses,vFSADlgCrosswalk);
    varDlgCrosswalk.pLFsaAppl = pCDlgCrosswalk;
    pTAppProcesses->pSetVarFSA->Add(varDlgCrosswalk);

    pFViewCrosswalk = new FViewCrosswalk("FViewCrosswalk");
    string vFSAViewCrosswalk = "ViewCrosswalk;FViewCrosswalk;ViewCrosswalk;0;0;0;0;SysDlg;1;1";
    static CVarFSA varViewCrosswalk(pTAppProcesses,vFSAViewCrosswalk);
    varViewCrosswalk.pLFsaAppl = pFViewCrosswalk;
    pTAppProcesses->pSetVarFSA->Add(varViewCrosswalk);

    pFCommonDecoder = new FCommonDecoder("FCommonDecoder");
    string vFSACommonDecoder = "CommonDecoder;FCommonDecoder;CommonDecoder;0;0;0;0;FsaWorld2;1;1";
    static CVarFSA varCommonDecoder(pTAppProcesses,vFSACommonDecoder);
    varCommonDecoder.pLFsaAppl = pFCommonDecoder;
    pTAppProcesses->pSetVarFSA->Add(varCommonDecoder);

    pFTestAppl = new FTestAppl("FTestAppl", this);
    string vFSATestAppl = "TestAppl;FTestAppl;TestAppl;0;0;0;0;SysDlg;1;1";
    static CVarFSA varTestAppl(pTAppProcesses,vFSATestAppl);
    varTestAppl.pLFsaAppl = pFTestAppl;
    pTAppProcesses->pSetVarFSA->Add(varTestAppl);
// отображение счетчиков объектов
    pFViewCounters = new FViewCounters("FViewCounters");
    string vFSAViewCounters = "ViewCounters;FViewCounters;ViewCounters;0;0;0;0;InitFsaWorld;1;1";
    static CVarFSA varViewCounters(pTAppProcesses,vFSAViewCounters);
    varViewCounters.pLFsaAppl = pFViewCounters;
    pTAppProcesses->pSetVarFSA->Add(varViewCounters);

    pTAppProcesses->pSetVarFSA->CreateProcesses();
    pFLightEasy_2->pVarStrInitColor->SetDataSrc(nullptr, "Green", nullptr);
    pFLightEasy_2->pVarStrInitColor->UpdateVariable();
    pFLightEasy_2->nCounter = 35;
    pFLightEasy_2->pVarCounter->SetDataSrc(nullptr, 35);
    pFLightEasy_2->pVarCounter->UpdateVariable();

    CIteratorVarFSA next = pTAppProcesses->pSetVarFSA->pArray->begin();
    while (next!=pTAppProcesses->pSetVarFSA->pArray->end()) {
        CVarFSA *pV = &*next;
        qDebug()<<"Load "<<pV->strName.c_str();
        next++;
    }
    SetParameters();
}


QString strBTN = "Stop All Tasks";
void MainWindow::on_IDC_BTN_StopAllTasks_clicked()
{
    if (strBTN == "Stop All Tasks") {
        strBTN = "Start All Tasks";
        ui->IDC_BTN_StopAllTasks->setText(strBTN);
        pTAppProcesses->StopAllTasks("");
    }
    else {
        strBTN = "Stop All Tasks";
        ui->IDC_BTN_StopAllTasks->setText(strBTN);
        pTAppProcesses->StartAllTasks("");
    }
}

void MainWindow::on_IDC_BTN_View_clicked()
{
    pCDlgCrosswalk->show();
}

void MainWindow::on_IDC_BTN_RestartTest_clicked()
{
    bRestartTest = true;
    pTAppProcesses->pCArrayNetFsa->ResetTasks();
    LoadingVariables();
    SetParameters();
    qDebug()<<"Restart VCPa";

}

void MainWindow::on_IDC_EDT_DeltaTime_editingFinished()
{
    QString qstr = ui->IDC_EDT_DeltaTime->text();
    int n = qstr.toInt();
    pVarSet->dDeltaTime = n;
    nDeltaTime = n;
}

void MainWindow::on_IDC_CHK_ViewCounters_clicked(bool checked)
{
    bIfViewCounters = checked;
}

void MainWindow::on_IDC_BTN_bIfStepByStep_clicked()
{
    if (pVarSet->bIfStepByStep) {
        if (pVarSet->bIfStopAllTasks) {
            pVarSet->bIfStopAllTasks = false;
        }
    }
    ui->IDC_BTN_bIfStepByStep->setChecked(true);
}

void MainWindow::on_IDC_CHK_bIfStepByStep_clicked(bool checked)
{
    if (pVarSet->bIfStepByStep != checked) {
        pVarSet->bIfStepByStep = checked;
        if (!checked) pVarSet->bIfStopAllTasks = false;
    }
}

void MainWindow::on_IDC_EDT_NumberOfFrames_editingFinished()
{
    QString qstr = ui->IDC_EDT_NumberOfFrames->text();
    long ln = qstr.toLong();
    lNumberOfFrames = ln;

}

void MainWindow::on_IDC_BTN_StartTest_clicked()
{
    if (!pVarStart)
        pVarStart = pTAppProcesses->pTAppDrv->pSetVarRead->GetAddressVar("bStart");
    if (pVarStart && demoFSM) {
        bool bStart = pVarStart->GetDataSrc();
        if (!bStart) {
            pVarStart->SetDataSrc(nullptr, 1);
        }
    }

}

void MainWindow::on_IDC_EDT_OperatingMode_editingFinished()
{
    pMainWindow->nOperatingMode = ui->IDC_EDT_OperatingMode->text().toInt();
    if (pMainWindow->nOperatingMode == 0) ui->IDC_TXT_OperatingMode->setText("Автоматное управление");
    if (pMainWindow->nOperatingMode == 1) ui->IDC_TXT_OperatingMode->setText("Таймерное управление");
    if (pMainWindow->nOperatingMode == 2) ui->IDC_TXT_OperatingMode->setText("Поточное управление");

}

void MainWindow::on_IDC_EDT_DeltaDelta_editingFinished()
{
    nDeltaDelta = ui->IDC_EDT_DeltaDelta->text().toInt();
}
