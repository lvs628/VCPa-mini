#ifndef DLGCROSSWALK_H
#define DLGCROSSWALK_H

#include "lfsaappl.h"
#include <QDialog>

namespace Ui {
class CDlgCrosswalk;
}

class FCrosswalk;
extern LArc TBL_DlgCrosswalk[];
class CDlgCrosswalk : public QDialog,
        public LFsaAppl
{
    Q_OBJECT

public:
    explicit CDlgCrosswalk(string strNam, LArc *pTBL=TBL_DlgCrosswalk, QWidget *parent = nullptr);
    ~CDlgCrosswalk();
    FCrosswalk *pFCrosswalk;
protected:
    void y1(); void y2();

private:
    Ui::CDlgCrosswalk *ui;
};

#endif // DLGCROSSWALK_H
