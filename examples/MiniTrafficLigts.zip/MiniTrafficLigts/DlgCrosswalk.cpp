#include "stdafx.h"
#include "DlgCrosswalk.h"
#include "ui_cdlgcrosswalk.h"
#include "./FsaExampl/Engee/TrafficLigths/FCrosswalk.h"

LArc TBL_DlgCrosswalk[] = {
    LArc("st",  "s1","--",	"y1"),
    LArc("s1",  "s1","--",	"y2"),
    LArc()
};


CDlgCrosswalk::CDlgCrosswalk(string strNam, LArc *pTBL, QWidget *parent) :
    QDialog(parent),
    LFsaAppl(pTBL, strNam, nullptr),
    ui(new Ui::CDlgCrosswalk)
{
    ui->setupUi(this);
    setWindowTitle("Crosswalk");
}

CDlgCrosswalk::~CDlgCrosswalk()
{
    delete ui;
}

void CDlgCrosswalk::y1() {
    pFCrosswalk = static_cast<FCrosswalk*>(FGetPtrFsaAppl("CrossEasy"));
//    show();
}

void CDlgCrosswalk::y2() {
    ui->IDC_EDIT_SortingTime->setText(pFCrosswalk->strTime.c_str());
}
