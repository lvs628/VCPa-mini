#include "stdafx.h"
#include "FTestAppl.h"
#include "mainwindow.h"
#include "TAppProcesses.h"

static LArc TBL_TestAppl[] = {
    LArc("st",		"st","^x12","y12"), // x12{true}
    LArc("st",		"s1","x12",	"y4"),	// y4{ задержка; }
    LArc("s1",		"s2","x5",	"y1y3"),// y1{число кадров:=0; "Start Test"; Стоп всех задач;}y3{bRestartTest = false;}
    LArc("s2",		"s3","--",	"y2"),	// y2{ bReset = false; Старт всех задач; }
    LArc("s3",		"s1","x2",	"y5"),	// x2(bReastartTest) y5{ bReset = false; }
    LArc()
};

FTestAppl::FTestAppl(string strNam, MainWindow *pMW):
    LFsaAppl(TBL_TestAppl, strNam, nullptr)
{
    pMWindow = pMW;
}

void FTestAppl::FResetActions() {
}


FTestAppl::~FTestAppl(void)
{
}

bool FTestAppl::FCreationOfLinksForVariables() {
// имя переменной режима работы
    pVarStrNameStart =  CreateLocVar("strNameStart", CLocVar::vtString, "start", true, "bStart");
    string str = pVarStrNameStart->strGetDataSrc();
    if (str!= "") { pVarStart = GetAddressVar(str); }
    if (pVarStart) {
        pVarStart->SetDataSrc(nullptr, 0.0);
        pVarStart->UpdateVariable();
    }
//
    pMWindow->nTheNumberOfTheCurrentFrame = 0;
    pMWindow->demoFSM = true;
    return true;
}

int FTestAppl::x1() { return pMWindow->lNumberOfFrames == pMWindow->nTheNumberOfTheCurrentFrame; }
int FTestAppl::x5() { return pVarStart->GetDataSrc(); }
int FTestAppl::x2() { return pMWindow->bRestartTest; }
int FTestAppl::x12() { return pVarStart!=nullptr; }

void FTestAppl::y1() {
    pMWindow->nTheNumberOfTheCurrentFrame = 0;
    qDebug()<<"Start Test";
    pMWindow->pTAppProcesses->StopAllTasks("InitFsaWorld");
//    pVarStart->SetDataSrc(nullptr, 0.0);
}

void FTestAppl::y2() {
    if (!bIfReset) {
//        pTAppCore->pCArrayNetFsa->ResetTasks();
        bIfReset = true;
    }
    pTAppProcesses->StartAllTasks("InitFsaWorld");

}
void FTestAppl::y3() { pMWindow->bRestartTest = false; }
void FTestAppl::y4() { FCreateDelay(1000); }
void FTestAppl::y5() { bIfReset = false; }
void FTestAppl::y12() { FInit(); }
