#ifndef FTESTAPPL_H
#define FTESTAPPL_H


#include "lfsaappl.h"

class MainWindow;
class FTestAppl :
    public LFsaAppl
{
public:
    void FResetActions();
    bool FCreationOfLinksForVariables();
    FTestAppl(string strNam, MainWindow *pMW);
    virtual ~FTestAppl(void);
    CVar    *pVarStrNameStart;
    CVar    *pVarStart;
protected:
    int x1(); int x5(); int x2(); int x12();
    void y1(); void y2(); void y3(); void y4(); void y5(); void y12();
    bool bIfReset{false};
    MainWindow *pMWindow;

};

#endif // FTESTAPPL_H
