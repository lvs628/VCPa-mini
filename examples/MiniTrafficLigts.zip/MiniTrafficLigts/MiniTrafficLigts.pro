QT       += core gui

greaterThan(QT_MAJOR_VERSION, 4): QT += widgets

CONFIG += c++11

# The following define makes your compiler emit warnings if you use
# any Qt feature that has been marked deprecated (the exact warnings
# depend on your compiler). Please consult the documentation of the
# deprecated API in order to know how to port your code away from it.
DEFINES += QT_DEPRECATED_WARNINGS
INCLUDEPATH += ../VCPA-mini/VCPA-mini/
INCLUDEPATH += ./FsaExampl/Engee/TrafficLigths/

# You can also make your code fail to compile if it uses deprecated APIs.
# In order to do so, uncomment the following line.
# You can also select to disable deprecated APIs only up to a certain version of Qt.
#DEFINES += QT_DISABLE_DEPRECATED_BEFORE=0x060000    # disables all the APIs deprecated before Qt 6.0.0

SOURCES += \
    ../VCPa-mini/VCPa-mini/ArithmeticMean.cpp \
    ../VCPa-mini/VCPa-mini/ArrayNetFsa.cpp \
    ../VCPa-mini/VCPa-mini/FDelay.cpp \
    ../VCPa-mini/VCPa-mini/FDelayCLK.cpp \
    ../VCPa-mini/VCPa-mini/LConvStr.cpp \
    ../VCPa-mini/VCPa-mini/LFsaHdr.cpp \
    ../VCPa-mini/VCPa-mini/Mfsttbl.cpp \
    ../VCPa-mini/VCPa-mini/NETFSA.cpp \
    ../VCPa-mini/VCPa-mini/SetLFsaHdr.cpp \
    ../VCPa-mini/VCPa-mini/SetVar.cpp \
    ../VCPa-mini/VCPa-mini/SetVarCircuit.cpp \
    ../VCPa-mini/VCPa-mini/SetVarFSA.cpp \
    ../VCPa-mini/VCPa-mini/SetVarFsaObject.cpp \
    ../VCPa-mini/VCPa-mini/SetVarNetFsa.cpp \
    ../VCPa-mini/VCPa-mini/SetVarPrmProc.cpp \
    ../VCPa-mini/VCPa-mini/SetVarSetting.cpp \
    ../VCPa-mini/VCPa-mini/StackTsk.cpp \
    ../VCPa-mini/VCPa-mini/StackWsp.cpp \
    ../VCPa-mini/VCPa-mini/TAppCore.cpp \
    ../VCPa-mini/VCPa-mini/TAppDrv.cpp \
    ../VCPa-mini/VCPa-mini/TAppProcesses.cpp \
    ../VCPa-mini/VCPa-mini/TAppVar.cpp \
    ../VCPa-mini/VCPa-mini/TDataDrv.cpp \
    ../VCPa-mini/VCPa-mini/TSetVarRead.cpp \
    ../VCPa-mini/VCPa-mini/TVarBase.cpp \
    ../VCPa-mini/VCPa-mini/TVarRead.cpp \
    ../VCPa-mini/VCPa-mini/Var.cpp \
    ../VCPa-mini/VCPa-mini/VarCircuit.cpp \
    ../VCPa-mini/VCPa-mini/VarFSA.cpp \
    ../VCPa-mini/VCPa-mini/VarFsaObject.cpp \
    ../VCPa-mini/VCPa-mini/VarPrmProc.cpp \
    ../VCPa-mini/VCPa-mini/VarSetting.cpp \
    ../VCPa-mini/VCPa-mini/Wsp.cpp \
    ../VCPa-mini/VCPa-mini/clocvar.cpp \
    ../VCPa-mini/VCPa-mini/csetlocvar.cpp \
    ../VCPa-mini/VCPa-mini/ctime.cpp \
    ../VCPa-mini/VCPa-mini/fssyslib.cpp \
    ../VCPa-mini/VCPa-mini/lfsaappl.cpp \
    ../VCPa-mini/VCPa-mini/task.cpp \
    ../VCPa-mini/VCPa-mini/vcpacore.cpp \
    ../VCPa-mini/VCPa-mini/vcpalibrary.cpp \
    DlgCrosswalk.cpp \
    FTestAppl.cpp \
    FsaExampl/Engee/TrafficLigths/FCommonCounter.cpp \
    FsaExampl/Engee/TrafficLigths/FCommonDecoder.cpp \
    FsaExampl/Engee/TrafficLigths/FCrossEasy.cpp \
    FsaExampl/Engee/TrafficLigths/FCrosswalk.cpp \
    FsaExampl/Engee/TrafficLigths/FLightEasy.cpp \
    FsaExampl/Engee/TrafficLigths/FTrafficLight.cpp \
    FsaExampl/Engee/TrafficLigths/FViewCounters.cpp \
    FsaExampl/Engee/TrafficLigths/FViewCrosswalk.cpp \
    FsaExampl/Engee/TrafficLigths/TrafficLigths.cpp \
    main.cpp \
    mainwindow.cpp \

HEADERS += \
    ../VCPa-mini/VCPa-mini/Arduino.h \
    ../VCPa-mini/VCPa-mini/ArithmeticMean.h \
    ../VCPa-mini/VCPa-mini/ArrayNetFsa.h \
    ../VCPa-mini/VCPa-mini/ConfigVCPa.h \
    ../VCPa-mini/VCPa-mini/Deffsa.h \
    ../VCPa-mini/VCPa-mini/DefineTypes.h \
    ../VCPa-mini/VCPa-mini/FDelay.h \
    ../VCPa-mini/VCPa-mini/FDelayCLK.h \
    ../VCPa-mini/VCPa-mini/LConvStr.h \
    ../VCPa-mini/VCPa-mini/LFsaHdr.h \
    ../VCPa-mini/VCPa-mini/SetLFsaHdr.h \
    ../VCPa-mini/VCPa-mini/SetVar.h \
    ../VCPa-mini/VCPa-mini/SetVarCircuit.h \
    ../VCPa-mini/VCPa-mini/SetVarFSA.h \
    ../VCPa-mini/VCPa-mini/SetVarNetFsa.h \
    ../VCPa-mini/VCPa-mini/SetVarPrmProc.h \
    ../VCPa-mini/VCPa-mini/SetVarSetting.h \
    ../VCPa-mini/VCPa-mini/StackTsk.h \
    ../VCPa-mini/VCPa-mini/StackWsp.h \
    ../VCPa-mini/VCPa-mini/Sttbl.h \
    ../VCPa-mini/VCPa-mini/TAppCore.h \
    ../VCPa-mini/VCPa-mini/TAppProcesses.h \
    ../VCPa-mini/VCPa-mini/TAppVar.h \
    ../VCPa-mini/VCPa-mini/TDataDrv.h \
    ../VCPa-mini/VCPa-mini/TSetVarRead.h \
    ../VCPa-mini/VCPa-mini/TVarBase.h \
    ../VCPa-mini/VCPa-mini/TVarRead.h \
    ../VCPa-mini/VCPa-mini/Var.h \
    ../VCPa-mini/VCPa-mini/VarFSA.h \
    ../VCPa-mini/VCPa-mini/VarFsaObject.h \
    ../VCPa-mini/VCPa-mini/VarPrmProc.h \
    ../VCPa-mini/VCPa-mini/VarSetting.h \
    ../VCPa-mini/VCPa-mini/Wsp.h \
    ../VCPa-mini/VCPa-mini/clocvar.h \
    ../VCPa-mini/VCPa-mini/csetlocvar.h \
    ../VCPa-mini/VCPa-mini/ctime.h \
    ../VCPa-mini/VCPa-mini/deffsadrv.h \
    ../VCPa-mini/VCPa-mini/deffsaprc.h \
    ../VCPa-mini/VCPa-mini/defvsavar.h \
    ../VCPa-mini/VCPa-mini/esp_timer.h \
    ../VCPa-mini/VCPa-mini/fsacore.h \
    ../VCPa-mini/VCPa-mini/larc.h \
    ../VCPa-mini/VCPa-mini/lfsaappl.h \
    ../VCPa-mini/VCPa-mini/netfsa.h \
    ../VCPa-mini/VCPa-mini/setvarfsaobject.h \
    ../VCPa-mini/VCPa-mini/stdafx.h \
    ../VCPa-mini/VCPa-mini/tappdrv.h \
    ../VCPa-mini/VCPa-mini/task.h \
    ../VCPa-mini/VCPa-mini/varcircuit.h \
    ../VCPa-mini/VCPa-mini/vcpacore.h \
    ../VCPa-mini/VCPa-mini/vcpalibrary.h \
    Arduino.h \
    DlgCrosswalk.h \
    FTestAppl.h \
    FsaExampl/Engee/TrafficLigths/FCommonCounter.h \
    FsaExampl/Engee/TrafficLigths/FCommonDecoder.h \
    FsaExampl/Engee/TrafficLigths/FCrossEasy.h \
    FsaExampl/Engee/TrafficLigths/FCrosswalk.h \
    FsaExampl/Engee/TrafficLigths/FLightEasy.h \
    FsaExampl/Engee/TrafficLigths/FTrafficLight.h \
    FsaExampl/Engee/TrafficLigths/FViewCounters.h \
    FsaExampl/Engee/TrafficLigths/FViewCrosswalk.h \
    mainwindow.h \

FORMS += \
    cdlgcrosswalk.ui \
    mainwindow.ui

# Default rules for deployment.
qnx: target.path = /tmp/$${TARGET}/bin
else: unix:!android: target.path = /opt/$${TARGET}/bin
!isEmpty(target.path): INSTALLS += target

DISTFILES += \
    ../VCPa-mini/VCPa-mini/README.txt \
    FsaExampl/Engee/TrafficLigths/README.txt \
    VCPa-mini/README.txt
