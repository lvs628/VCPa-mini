QT       += core gui

greaterThan(QT_MAJOR_VERSION, 4): QT += widgets

CONFIG += c++11

# The following define makes your compiler emit warnings if you use
# any Qt feature that has been marked deprecated (the exact warnings
# depend on your compiler). Please consult the documentation of the
# deprecated API in order to know how to port your code away from it.
DEFINES += QT_DEPRECATED_WARNINGS
INCLUDEPATH += ./VCPA-mini/

# You can also make your code fail to compile if it uses deprecated APIs.
# In order to do so, uncomment the following line.
# You can also select to disable deprecated APIs only up to a certain version of Qt.
#DEFINES += QT_DISABLE_DEPRECATED_BEFORE=0x060000    # disables all the APIs deprecated before Qt 6.0.0

SOURCES += \
    DlgCrosswalk.cpp \
    FTestAppl.cpp \
    FsaExampl/Engee/TrafficLigths/FCommonCounter.cpp \
    FsaExampl/Engee/TrafficLigths/FCommonDecoder.cpp \
    FsaExampl/Engee/TrafficLigths/FCrossEasy.cpp \
    FsaExampl/Engee/TrafficLigths/FCrosswalk.cpp \
    FsaExampl/Engee/TrafficLigths/FLightEasy.cpp \
    FsaExampl/Engee/TrafficLigths/FTrafficLight.cpp \
    FsaExampl/Engee/TrafficLigths/FViewCounters.cpp \
    FsaExampl/Engee/TrafficLigths/FViewCrosswalk.cpp \
    FsaExampl/Engee/TrafficLigths/TrafficLigths.cpp \
    VCPa-mini/ArithmeticMean.cpp \
    VCPa-mini/ArrayNetFsa.cpp \
    VCPa-mini/FDelay.cpp \
    VCPa-mini/FDelayCLK.cpp \
    VCPa-mini/LConvStr.cpp \
    VCPa-mini/LFsaHdr.cpp \
    VCPa-mini/Mfsttbl.cpp \
    VCPa-mini/NETFSA.cpp \
    VCPa-mini/SetLFsaHdr.cpp \
    VCPa-mini/SetVar.cpp \
    VCPa-mini/SetVarCircuit.cpp \
    VCPa-mini/SetVarFSA.cpp \
    VCPa-mini/SetVarFsaObject.cpp \
    VCPa-mini/SetVarNetFsa.cpp \
    VCPa-mini/SetVarPrmProc.cpp \
    VCPa-mini/SetVarSetting.cpp \
    VCPa-mini/StackTsk.cpp \
    VCPa-mini/StackWsp.cpp \
    VCPa-mini/TAppCore.cpp \
    VCPa-mini/TAppDrv.cpp \
    VCPa-mini/TAppProcesses.cpp \
    VCPa-mini/TAppVar.cpp \
    VCPa-mini/TDataDrv.cpp \
    VCPa-mini/TSetVarRead.cpp \
    VCPa-mini/TVarBase.cpp \
    VCPa-mini/TVarRead.cpp \
    VCPa-mini/Var.cpp \
    VCPa-mini/VarCircuit.cpp \
    VCPa-mini/VarFSA.cpp \
    VCPa-mini/VarFsaObject.cpp \
    VCPa-mini/VarPrmProc.cpp \
    VCPa-mini/VarSetting.cpp \
    VCPa-mini/Wsp.cpp \
    VCPa-mini/clocvar.cpp \
    VCPa-mini/csetlocvar.cpp \
    VCPa-mini/ctime.cpp \
    VCPa-mini/fssyslib.cpp \
    VCPa-mini/lfsaappl.cpp \
    VCPa-mini/task.cpp \
    VCPa-mini/vcpacore.cpp \
    main.cpp \
    mainwindow.cpp \
    vcpalibrary.cpp

HEADERS += \
    Arduino.h \
    ConfigVCPa.h \
    DlgCrosswalk.h \
    FTestAppl.h \
    FsaExampl/Engee/TrafficLigths/FCommonCounter.h \
    FsaExampl/Engee/TrafficLigths/FCommonDecoder.h \
    FsaExampl/Engee/TrafficLigths/FCrossEasy.h \
    FsaExampl/Engee/TrafficLigths/FCrosswalk.h \
    FsaExampl/Engee/TrafficLigths/FLightEasy.h \
    FsaExampl/Engee/TrafficLigths/FTrafficLight.h \
    FsaExampl/Engee/TrafficLigths/FViewCounters.h \
    FsaExampl/Engee/TrafficLigths/FViewCrosswalk.h \
    VCPa-mini/ArithmeticMean.h \
    VCPa-mini/ArrayNetFsa.h \
    VCPa-mini/Deffsa.h \
    VCPa-mini/DefineTypes.h \
    VCPa-mini/FDelay.h \
    VCPa-mini/FDelayCLK.h \
    VCPa-mini/LConvStr.h \
    VCPa-mini/LFsaHdr.h \
    VCPa-mini/SetLFsaHdr.h \
    VCPa-mini/SetVar.h \
    VCPa-mini/SetVarCircuit.h \
    VCPa-mini/SetVarFSA.h \
    VCPa-mini/SetVarNetFsa.h \
    VCPa-mini/SetVarPrmProc.h \
    VCPa-mini/SetVarSetting.h \
    VCPa-mini/StackTsk.h \
    VCPa-mini/StackWsp.h \
    VCPa-mini/Sttbl.h \
    VCPa-mini/TAppCore.h \
    VCPa-mini/TAppProcesses.h \
    VCPa-mini/TAppVar.h \
    VCPa-mini/TDataDrv.h \
    VCPa-mini/TSetVarRead.h \
    VCPa-mini/TVarBase.h \
    VCPa-mini/TVarRead.h \
    VCPa-mini/Var.h \
    VCPa-mini/VarFSA.h \
    VCPa-mini/VarFsaObject.h \
    VCPa-mini/VarPrmProc.h \
    VCPa-mini/VarSetting.h \
    VCPa-mini/Wsp.h \
    VCPa-mini/clocvar.h \
    VCPa-mini/csetlocvar.h \
    VCPa-mini/ctime.h \
    VCPa-mini/deffsadrv.h \
    VCPa-mini/deffsaprc.h \
    VCPa-mini/defvsavar.h \
    VCPa-mini/fsacore.h \
    VCPa-mini/larc.h \
    VCPa-mini/lfsaappl.h \
    VCPa-mini/netfsa.h \
    VCPa-mini/setvarfsaobject.h \
    VCPa-mini/stdafx.h \
    VCPa-mini/tappdrv.h \
    VCPa-mini/task.h \
    VCPa-mini/varcircuit.h \
    VCPa-mini/vcpacore.h \
    esp_timer.h \
    mainwindow.h \
    vcpalibrary.h

FORMS += \
    cdlgcrosswalk.ui \
    mainwindow.ui

# Default rules for deployment.
qnx: target.path = /tmp/$${TARGET}/bin
else: unix:!android: target.path = /opt/$${TARGET}/bin
!isEmpty(target.path): INSTALLS += target

DISTFILES += \
    FsaExampl/Engee/TrafficLigths/README.txt \
    VCPa-mini/README.txt
