#include "mainwindow.h"

#include <QApplication>

MainWindow *pMainWindow{nullptr};
int main(int argc, char *argv[])
{
    int n = argc;
    int m;
    if (n>0) {
        m = QString(argv[1]).toUInt();
    }
    QApplication a(argc, argv);
    MainWindow w;
    pMainWindow = &w;
    pMainWindow->nOperatingMode = m;
    pMainWindow->LoadingProsesses();
    w.show();
    return a.exec();
}
