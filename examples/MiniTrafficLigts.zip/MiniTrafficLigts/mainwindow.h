#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "VCPa-mini/ctime.h"
#include "stdafx.h"
#include <QElapsedTimer>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class FLightEasy;
class FCrossEasy;
class FCommonDecoder;
class FCrosswalk;
class FViewCrosswalk;
class CDlgCrosswalk;
class FTestAppl;
class FViewCounters;
class TAppProcesses;
class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    CTime tickT0;
    CVar            *pVarStart{nullptr};
    QElapsedTimer   timeApp;

    virtual void timerEvent(QTimerEvent*);
    void LoadingProsesses();
    void LoadingVariables();
    void SetParameters();
    FLightEasy      *pFLightEasy_1;
    FLightEasy      *pFLightEasy_2;
    FCrossEasy      *pFCrossEasy;
    FCommonDecoder  *pFCommonDecoder;
    FViewCrosswalk  *pFViewCrosswalk;
    CDlgCrosswalk   *pCDlgCrosswalk;
    FTestAppl       *pFTestAppl;
    FViewCounters   *pFViewCounters;
    void ViewTime(QString qstrT);
    bool demoFSM{true};
    long lNumberOfFrames{2};
    CVarSetting *pVarSet;
    bool    bRestartTest{false};
    int     nDeltaTime{100};
    int     nDeltaDelta{0};
    bool    bIfViewCounters{false};
    int     nTheNumberOfTheCurrentFrame{0};
    int     nOperatingMode{0};              // режим работы
    TAppProcesses *pTAppProcesses{nullptr};
private slots:
    void on_IDC_BTN_StopAllTasks_clicked();

    void on_IDC_BTN_View_clicked();

    void on_IDC_BTN_RestartTest_clicked();

    void on_IDC_EDT_DeltaTime_editingFinished();

    void on_IDC_CHK_ViewCounters_clicked(bool checked);

    void on_IDC_BTN_bIfStepByStep_clicked();

    void on_IDC_CHK_bIfStepByStep_clicked(bool checked);

    void on_IDC_EDT_NumberOfFrames_editingFinished();

    void on_IDC_BTN_StartTest_clicked();

    void on_IDC_EDT_OperatingMode_editingFinished();

    void on_IDC_EDT_DeltaDelta_editingFinished();


private:
    Ui::MainWindow *ui;
    bool    bStart{false};
    int nSavCnt{-1};
};
#endif // MAINWINDOW_H
