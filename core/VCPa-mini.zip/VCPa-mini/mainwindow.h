#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "VCPa-mini/ctime.h"
#include "stdafx.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class TAppProcesses;
class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    CTime tickT0;

    virtual void timerEvent(QTimerEvent*);
    void LoadingFsaProsesses();

private:
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H
