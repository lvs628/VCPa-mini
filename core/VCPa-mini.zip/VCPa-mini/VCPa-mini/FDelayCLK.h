// FDelayCLK.h: interface for the FDelayCLK class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FDELAYCLK_H__129859E1_89D6_11D7_B50B_00C0DF0F1E3A__INCLUDED_)
#define AFX_FDELAYCLK_H__129859E1_89D6_11D7_B50B_00C0DF0F1E3A__INCLUDED_
#pragma once
#include "defvsavar.h"
#include "lfsaappl.h"


class FDelayCLK : public LFsaAppl
{
public:
//    FDelayCLK(string strNam);
    FDelayCLK(long lD, long *plD=nullptr);
	virtual ~FDelayCLK();
	long GetDelay();
	void SetDelay(long lD, long *plD=nullptr);
	void Add(long lD);
	void Sub(long lD);

protected:
	int x1();
	int x2();
	int x3();
	void y1();
	void y2();

protected:
	long lDelay;
	long *plDelay;
	long lCurrent;
};

#endif // !defined(AFX_FDELAYCLK_H__129859E1_89D6_11D7_B50B_00C0DF0F1E3A__INCLUDED_)
