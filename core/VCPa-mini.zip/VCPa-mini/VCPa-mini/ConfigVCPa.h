#ifndef CONFIG_H
#define CONFIG_H
//#define IF_DPP
#define IF_USING_FSM_MAX_SPEED
//#define IF_ASYNCHRONOUS_MODE
//#define IF_CONNECT_WIFI

#endif // CONFIG_H
