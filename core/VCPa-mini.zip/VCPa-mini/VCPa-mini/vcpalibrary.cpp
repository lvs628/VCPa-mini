#include "vcpalibrary.h"
#include "ctime.h"
#include "mainwindow.h"

extern MainWindow *pMainWindow;

CTime tickT0;

//unsigned long lastUpdateTime;

int64_t  millis()
{
    return pMainWindow->pTAppProcesses->tickT0.elapsed()/1000;
}
vector<string> splitString(const string& input, char delimiter) {
    vector<std::string> tokens;
    stringstream ss(input);
    string token;

    while (getline(ss, token, delimiter)) {
        if (!token.empty()) {
            tokens.push_back(token);
        }
    }
    return tokens;
}

vector<string> splitString(const string& input, const string& delimiter) {
    vector<string> result;
    size_t start = 0;
    size_t end = input.find(delimiter);

    while (end != string::npos) {
        string token = input.substr(start, end - start);
        if (!token.empty()) {  // Игнорируем пустые подстроки
            result.push_back(token);
        }
        start = end + delimiter.length();
        end = input.find(delimiter, start);
    }
    // Добавляем последний элемент (если не пустой)
    string lastToken = input.substr(start);
    if (!lastToken.empty()) {
        result.push_back(lastToken);
    }
    return result;
}

string itoa(int n) {
    char retbuf[20];
    sprintf(retbuf, "%d", n);
    return string(retbuf);
}
/*
int64_t esp_timer_get_time()
{
    int64_t l = pMainWindow->tickT0.elapsed();
//    double l = pMainWindow->tickT0.elapsed();
    return l;
//    return l;
}
*/
#include <sstream>
#include <vector>
using namespace std;
int64_t esp_timer_get_time()
{
    int64_t l = pMainWindow->pTAppProcesses->tickT0.elapsed();
    return l*1000*1000;
}

int random(int num)
{
    int n = rand();
    double m =  (n/32767.0)*num;
    if (m<1)
        m *=num;
    return m;
}
