#pragma once
#include "fsacore.h"

#include "SetLFsaHdr.h"

typedef vector<TNetFsa*> TIArrayNetFsa;
typedef vector<TNetFsa*>::iterator TIIteratorNetFsa;
typedef vector<TNetFsa> TArrayNetFsa;
typedef vector<TNetFsa>::iterator TIteratorNetFsa;

class TAppCore;
class CArrayNetFsa  
{
public:
    void    ResetTasks();
    long	GetNumberOfTasks(long *lAct);
	TNetFsa* GetAdressNetFsa(string strName);
	LFsaAppl* GetAdressFsaAppl(string str, int *pr, TNetFsa **pNet);
    bool InitNetFsa();
    TNetFsa* GetNetFsa(string str, string strConfig);
	CArrayNetFsa(TAppCore *pCore);
	virtual ~CArrayNetFsa();
	virtual bool OnIdleFsa(long lCount);

	TNetFsa* pNetFsa;

    TIArrayNetFsa IArrayNetFsa;
//    TIIteratorNetFsa IIteratorNetFsa;         // так не работает

	CSetLFsaHdr	*pSetLFsaHdr;
	long	lNumberOfTasks;
	long	lNumberOfActiveTasks;
	TAppCore	*pTAppCore;
};
