#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "TAppProcesses.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    // создаем среду исполнения автоматов
    pTAppProcesses = VCPaCore_init();

    startTimer(0);           // запускаем дискретное время среды
}

MainWindow::~MainWindow()
{
    delete ui;
    if (pTAppProcesses) VCPaCore_delete();
}

void MainWindow::timerEvent(QTimerEvent* t) {
    int nId = t->timerId();
    VCPaCore_TimerEvent(nId);                                           // исполняем одиин такт среды
}

void MainWindow::LoadingFsaProsesses()
{
}

