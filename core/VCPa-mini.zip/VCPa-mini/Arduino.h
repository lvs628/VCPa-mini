#ifndef ARDUINO_H
#define ARDUINO_H

#include <cstring>

typedef unsigned int uint;

#endif // ARDUINO_H
