#ifndef ESP_TIMER_H
#define ESP_TIMER_H
#include <sstream>
#include <vector>
using namespace std;

int64_t esp_timer_get_time();
//qint64 esp_timer_get_time();
//long esp_timer_get_time();

#endif // ESP_TIMER_H
